# Avespy

**Kenali Nomor. Hindari Penipuan.**

Platform pengecekan nomor telepon (caller identification) yang hanya memakai data sah: parsing E.164, negara, indikasi operator, tipe nomor, dan laporan komunitas yang dimoderasi. Tidak ada data pribadi sensitif, tidak ada database bocor, tidak ada scraping.

## Menjalankan (lokal)

Prasyarat: Node.js 20+ dan Docker (untuk PostgreSQL), atau PostgreSQL 14+ sendiri.

```bash
cp .env.example .env          # isi ADMIN_EMAIL dan ADMIN_PASSWORD (min. 12 karakter)
docker compose up -d          # PostgreSQL
npm install
npm run db:migrate            # buat tabel + referensi prefix operator
npm run db:seed-admin         # buat akun moderator/admin pertama
npm run dev                   # http://localhost:3000
```

- Situs publik: `http://localhost:3000`
- Dashboard moderator: `http://localhost:3000/admin`
- Tes unit (logika skor risiko): `npm test`

Karena tidak ada data palsu, semua nomor awalnya berstatus **Belum Ada Laporan / DATA TIDAK TERSEDIA**. Untuk mencoba alurnya: kirim laporan di halaman Laporan, lalu setujui di dashboard admin.

## Arsitektur

```
Frontend (ES Modules)
  Page -> Component -> Service -> API layer (js/api) -> fetch
                                        |
                                   Express API
                 Auth (token sesi/JWT) -> Validasi -> Rate limit / Abuse
                                        |
                                Phone Number Service (libphonenumber, E.164)
                                        |
                       Risk/Spam Service  <->  PostgreSQL (laporan, penekanan, audit)
```

Komponen tidak pernah memanggil `fetch`; hanya `frontend/js/api/` yang tahu URL backend.

```
frontend/  index.html, admin.html, css/, js/{app.js,pages,components,services,api,utils,admin}
server/src/{routes,middleware,services,validation,db,utils}
```

## Endpoint

| Metode | Path | Auth | Keterangan |
|---|---|---|---|
| POST | `/api/session` | - | Token sesi anonim (JWT 30 menit) |
| GET | `/api/config`, `/api/captcha` | - | Daftar negara, penyedia CAPTCHA |
| POST | `/api/lookup` | Bearer | Cek **satu** nomor |
| POST | `/api/reports` | Bearer + CAPTCHA | Kirim laporan (status awal `pending`) |
| GET | `/api/reports/:number` | Bearer | Laporan disetujui untuk satu nomor E.164 (`%2B62...`) |
| DELETE | `/api/reports/:id` | Bearer + token hapus | Pelapor menghapus laporannya sendiri |
| POST | `/api/removal-request` | Bearer + CAPTCHA | Pemilik nomor meminta penghapusan |
| `/api/admin/*` | cookie httpOnly + CSRF + peran | | Moderasi, statistik, abuse, audit |

## Anti-abuse yang diterapkan

- **Rate limiting** per endpoint dan global, **request throttling** (perlambatan bertahap) pada pencarian.
- **CAPTCHA**: bawaan (soal bertanda tangan HMAC, sekali pakai) atau Cloudflare Turnstile (`CAPTCHA_PROVIDER=turnstile`). Wajib untuk laporan dan permintaan penghapusan; untuk pencarian diminta setelah 3 nomor berbeda per jam.
- **Deteksi IP abuse**: pencarian dibatasi 25 nomor berbeda/jam; pola enumerasi nomor berurutan (6+ nomor yang hanya beda 3 digit terakhir dalam 10 menit) memblokir IP selama 1 jam. Tidak ada endpoint yang menerima banyak nomor sekaligus.
- **API authentication**: semua endpoint publik butuh token sesi; admin memakai JWT di cookie `httpOnly` + `SameSite=Strict` + token CSRF (double-submit) + pengecekan Origin, kunci akun setelah 5 gagal login, peran diambil dari database.
- **Audit logging** ke tabel `audit_logs`; kejadian abuse ke `abuse_events`.
- **Input validation** (zod) di semua endpoint; nomor dinormalisasi ke E.164 dan divalidasi libphonenumber.
- **Privasi**: IP hanya disimpan sebagai HMAC berkunci (`HASH_PEPPER`); nomor yang dicari tidak dicatat (hanya statistik agregat per negara); deskripsi laporan ditolak bila memuat email, tautan, atau angka panjang (telepon/NIK/rekening); tag komunitas hanya tampil bila dipakai >= 3 pelapor berbeda.
- Helmet + CSP ketat (tanpa inline script/style), DOM dibangun tanpa `innerHTML`.
- Penghapusan otomatis sesuai Privacy Center (`retentionService.js`).

## Sumber data & kejujuran hasil

1. libphonenumber (metadata terbuka): format, validitas, negara, tipe.
2. Tabel `carrier_prefixes` (referensi prefix numbering plan Indonesia, diisi `migrate.js`): **indikasi** operator, selalu berkepercayaan rendah karena portabilitas nomor. Perbarui dari data resmi regulator secara berkala.
3. Laporan komunitas yang sudah disetujui moderator.

Bila sumber tidak punya data, UI menampilkan **DATA TIDAK TERSEDIA**; bila layanan gagal, pengguna melihat pesan galat, bukan data pengganti. Nomor tanpa laporan berstatus "Belum Ada Laporan", bukan "aman".

## Alur penghapusan data

Permintaan masuk antrean moderator. **Moderator wajib memverifikasi kepemilikan nomor** (mis. OTP atau tautan lewat kanal resmi) sebelum menyetujui; dashboard meminta catatan verifikasi. Persetujuan menghapus semua laporan nomor itu, menyimpan hash nomor di `suppressed_numbers`, dan mengosongkan nomor mentah dari permintaan.

## Checklist production

- Set `NODE_ENV=production`, `JWT_SECRET`, `HASH_PEPPER` (>= 32 karakter acak; aplikasi menolak start bila kosong), `DB_SSL`, `TRUST_PROXY` (jumlah proxy di depan aplikasi), dan pakai HTTPS.
- State deteksi abuse dan rate limit ada di memori proses. Untuk lebih dari satu instance, pindahkan ke Redis (`express-rate-limit` mendukung store Redis; `abuseDetector.js` terisolasi untuk diganti).
- Tambahkan 2FA (TOTP) untuk akun admin dan halaman kontak resmi di Privacy Center.
- Ganti tabel `carrier_prefixes` dengan sumber resmi yang Anda punya izinnya, dan tinjau Terms/Privacy dengan penasihat hukum (UU PDP).
- Ganti `Turnstile`/CAPTCHA bawaan sesuai tingkat risiko.
