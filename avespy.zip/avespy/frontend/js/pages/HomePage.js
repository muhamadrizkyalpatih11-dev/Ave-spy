import { h } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { SearchBox } from '../components/SearchBox.js';
import { RiskBadge } from '../components/RiskBadge.js';
import { navigate } from '../utils/router.js';
import { setHandoff } from '../utils/handoff.js';
import { validateNumberInput } from '../utils/validators.js';

const NEVER = [
  'Alamat rumah, NIK/KTP, atau lokasi real-time',
  'Isi SMS atau WhatsApp',
  'Data rekening dan password',
  'Kontak pribadi pengguna lain',
  'Data dari database bocor atau perangkat orang lain',
];

export function HomePage() {
  const search = SearchBox({
    onSubmit(value) {
      const problem = validateNumberInput(value.number);
      if (problem) {
        search.setError(problem);
        search.focus();
        return;
      }
      setHandoff({ kind: 'check', value });
      navigate('/cek');
    },
  });

  const legend = h('aside', { class: 'card legend', 'aria-labelledby': 'legend-title' },
    h('h2', { id: 'legend-title', class: 'h3' }, 'Cara membaca hasil'),
    h('ul', { class: 'legend-list' },
      h('li', {}, RiskBadge('low'), h('span', {}, 'Ada sedikit laporan berbobot ringan, misalnya telemarketing.')),
      h('li', {}, RiskBadge('caution'), h('span', {}, 'Ada laporan penipuan atau spam. Jangan bagikan kode OTP atau data pribadi.')),
      h('li', {}, RiskBadge('spam'), h('span', {}, 'Banyak pelapor berbeda melaporkan nomor ini baru-baru ini.')),
      h('li', {}, RiskBadge('unknown'), h('span', {}, 'Belum ada laporan yang disetujui. Ini bukan jaminan nomor aman.'))));

  const el = h('div', {},
    h('section', { class: 'hero container' },
      h('div', { class: 'hero-copy' },
        h('p', { class: 'wordmark' }, 'AVESPY'),
        h('h1', {}, 'Kenali Nomor. Hindari Penipuan.'),
        h('p', { class: 'lead' }, 'Periksa nomor telepon dan lihat informasi risiko berdasarkan data yang tersedia secara legal dan laporan komunitas.'),
        search.el),
      legend),

    h('section', { class: 'container section' },
      h('h2', {}, 'Yang diperiksa Avespy'),
      h('div', { class: 'triple' },
        h('div', {}, icon('phone', 24), h('h3', {}, 'Format dan validitas'), h('p', {}, 'Nomor dinormalisasi ke format E.164, lalu dicek negara, kode negara, dan tipenya: seluler, telepon rumah, atau VoIP.')),
        h('div', {}, icon('tower', 24), h('h3', {}, 'Operator'), h('p', {}, 'Ditampilkan bila tersedia dari alokasi prefix. Karena nomor bisa berpindah operator, kami menandainya sebagai indikasi.')),
        h('div', {}, icon('users', 24), h('h3', {}, 'Laporan komunitas'), h('p', {}, 'Laporan ditinjau moderator sebelum dihitung. Skor memperhitungkan jenis laporan, jumlah pelapor berbeda, dan kebaruan.')))),

    h('section', { class: 'container section' },
      h('div', { class: 'card promise' },
        h('div', {}, icon('lock', 26), h('h2', {}, 'Yang tidak pernah kami tampilkan'),
          h('p', {}, 'Avespy bukan alat pelacak orang. Jika data tidak ada, kami menulis DATA TIDAK TERSEDIA, bukan menebak.')),
        h('ul', { class: 'plain-list' }, NEVER.map((t) => h('li', {}, t))))));

  return { title: 'Kenali Nomor. Hindari Penipuan.', el, destroy() {} };
}
