import { h } from '../utils/dom.js';
import { ReportForm } from '../components/ReportForm.js';
import { CommunityReports } from '../components/CommunityReports.js';
import { DeleteReportForm } from '../components/DeleteReportForm.js';
import { takeHandoff } from '../utils/handoff.js';

export function ReportsPage() {
  const pending = takeHandoff();
  const form = ReportForm({ initial: pending?.kind === 'report' ? pending.value : null });
  const viewer = CommunityReports();
  const remove = DeleteReportForm();

  const el = h('section', { class: 'container page' },
    h('h1', {}, 'Laporan'),
    h('p', { class: 'lead' }, 'Laporan Anda membantu orang lain mengenali nomor bermasalah. Setiap laporan ditinjau moderator sebelum dihitung, dan laporan palsu atau fitnah dapat ditolak atau dihapus.'),
    h('div', { class: 'two-col' }, form.el, h('div', { class: 'stack' }, viewer.el, remove.el)));

  if (pending?.kind === 'view') queueMicrotask(() => viewer.run(pending.value));

  return { title: 'Laporan', el, destroy() {} };
}
