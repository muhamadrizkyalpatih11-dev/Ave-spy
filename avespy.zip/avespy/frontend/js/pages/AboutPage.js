import { h } from '../utils/dom.js';

export function AboutPage() {
  const el = h('article', { class: 'container page prose' },
    h('h1', {}, 'Tentang Avespy'),
    h('p', { class: 'lead' }, 'Avespy membantu orang mengenali telepon dan pesan bermasalah sebelum terlanjur menjawab, mentransfer uang, atau membagikan kode OTP.'),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Sumber data'),
      h('ul', { class: 'bullets' }, [
        h('li', {}, h('strong', {}, 'libphonenumber'), ': metadata terbuka untuk format, validitas, negara, dan tipe nomor.'),
        h('li', {}, h('strong', {}, 'Referensi prefix numbering plan'), ': indikasi operator. Portabilitas nomor membuatnya tidak selalu akurat, sehingga kami menandainya berkepercayaan rendah.'),
        h('li', {}, h('strong', {}, 'Laporan komunitas'), ': dikirim pengguna dengan persetujuan, ditinjau moderator, lalu dihitung.'),
      ]),
      h('p', {}, 'Kami tidak memakai data dari database bocor, scraping kontak, atau akses ke perangkat dan akun orang lain.')),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Bila data tidak ada'),
      h('p', {}, 'Avespy menampilkan DATA TIDAK TERSEDIA. Kami tidak mengisi kekosongan dengan tebakan, dan bila layanan gagal kami menampilkan pesan galat, bukan data pengganti.')),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Cara skor risiko dihitung'),
      h('p', {}, 'Setiap laporan yang disetujui diberi bobot menurut kategorinya (penipuan dan phishing paling berat, telemarketing paling ringan) dan meluruh seiring waktu. Tingkat kepercayaan naik bila laporan datang dari banyak pelapor berbeda. Tag komunitas baru tampil bila dipakai minimal tiga pelapor.')));
  return { title: 'Tentang', el, destroy() {} };
}
