import { h } from '../utils/dom.js';
import { SearchBox } from '../components/SearchBox.js';
import { LoadingProgress } from '../components/LoadingProgress.js';
import { ResultCard } from '../components/ResultCard.js';
import { Notice } from '../components/Notice.js';
import { runGated } from '../components/CaptchaGate.js';
import { checkNumber } from '../services/lookupService.js';
import { messageOf } from '../utils/errors.js';
import { navigate } from '../utils/router.js';
import { setHandoff, takeHandoff } from '../utils/handoff.js';

export function CheckPage() {
  const gate = h('div');
  const progress = LoadingProgress();
  const out = h('div', { class: 'result-host', 'aria-live': 'polite' });
  const search = SearchBox({ onSubmit: run });
  let runId = 0;

  async function run(value) {
    const id = ++runId;
    search.setError(null);
    out.replaceChildren();
    gate.replaceChildren();
    search.setBusy(true);
    const attempt = async (captcha) => {
      progress.start();
      try {
        return await checkNumber({ ...value, captcha });
      } finally {
        progress.stop();
      }
    };
    try {
      const data = await runGated(attempt, gate);
      if (id !== runId) return;
      out.replaceChildren(ResultCard(data, {
        onReport(d) {
          setHandoff({ kind: 'report', value: { region: d.country.code || 'ID', number: d.number.e164 } });
          navigate('/laporan');
        },
        onShowMore(e164) {
          setHandoff({ kind: 'view', value: { region: 'ID', number: e164 } });
          navigate('/laporan');
        },
      }));
    } catch (err) {
      const msg = messageOf(err);
      if (err.code === 'VALIDATION_ERROR' || err.code === 'INVALID_NUMBER') {
        search.setError(msg);
        search.focus();
      } else {
        out.replaceChildren(Notice('error', msg));
      }
    } finally {
      search.setBusy(false);
    }
  }

  const el = h('section', { class: 'container page' },
    h('h1', {}, 'Cek Nomor'),
    h('p', { class: 'lead' }, 'Masukkan satu nomor telepon. Avespy menampilkan informasi yang tersedia dan menandai dengan jelas bila datanya tidak ada.'),
    search.el, gate, progress.el, out);

  const pending = takeHandoff();
  if (pending?.kind === 'check') {
    search.setValue(pending.value);
    queueMicrotask(() => run(pending.value));
  }

  return { title: 'Cek Nomor', el, destroy() { runId += 1; } };
}
