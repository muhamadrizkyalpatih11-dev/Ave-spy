import { h } from '../utils/dom.js';
import { RemovalForm } from '../components/RemovalForm.js';

const section = (title, ...body) => h('section', { class: 'prose-block' }, h('h2', {}, title), ...body);
const list = (items) => h('ul', { class: 'bullets' }, items.map((t) => h('li', {}, t)));

export function PrivacyPage() {
  const removal = RemovalForm();
  const el = h('article', { class: 'container page prose' },
    h('h1', {}, 'Privacy Center'),
    h('p', { class: 'lead' }, 'Avespy dirancang agar mengumpulkan sesedikit mungkin data. Halaman ini menjelaskan apa yang kami simpan, mengapa, dan bagaimana Anda mengendalikannya.'),

    section('Data yang kami kumpulkan',
      list([
        'Laporan komunitas: nomor telepon (E.164), kategori, tag pilihan, deskripsi singkat, dan waktu laporan.',
        'Identitas pelapor berupa hash berkunci dari alamat IP. IP asli tidak disimpan di database laporan.',
        'Statistik pencarian agregat per hari dan negara. Nomor yang Anda cari tidak disimpan.',
        'Catatan keamanan (rate limit, percobaan penyalahgunaan) dengan hash IP, bukan IP asli.',
        'Permintaan penghapusan data: nomor, email kontak, dan alasan.',
      ])),

    section('Alasan pengumpulan',
      list([
        'Menampilkan risiko nomor dari laporan komunitas yang dimoderasi.',
        'Mencegah duplikasi laporan, spam, dan pencarian massal.',
        'Memproses permintaan penghapusan dan menjaga jejak audit moderasi.',
      ])),

    section('Berapa lama data disimpan',
      list([
        'Laporan disetujui: 24 bulan, lalu dihapus otomatis.',
        'Laporan menunggu tinjauan: maksimal 90 hari. Laporan ditolak: 30 hari.',
        'Email pada permintaan penghapusan: dihapus 30 hari setelah permintaan selesai.',
        'Catatan penyalahgunaan: 30 hari. Audit log moderasi: 12 bulan. Statistik agregat: 24 bulan.',
      ])),

    section('Menghapus laporan Anda',
      h('p', {}, 'Saat mengirim laporan Anda menerima ID dan token penghapusan. Masukkan keduanya di halaman ', h('a', { href: '#/laporan' }, 'Laporan'), ' untuk menghapus laporan itu secara permanen.')),

    section('Meminta penghapusan informasi tentang nomor Anda',
      h('p', {}, 'Jika Anda pemilik nomor, ajukan permintaan di bawah. Setelah moderator memverifikasi kepemilikan, seluruh laporan untuk nomor itu dihapus dan nomor tidak lagi menampilkan informasi komunitas atau menerima laporan baru. Kami hanya menyimpan hash nomor untuk menegakkan permintaan tersebut.'),
      removal.el),

    section('Larangan penyalahgunaan',
      h('p', {}, 'Avespy tidak boleh dipakai untuk menguntit, melecehkan, membuka identitas orang (doxxing), penipuan, atau tujuan lain yang merugikan. Pencarian massal dan pola enumerasi nomor diblokir otomatis. Lihat ', h('a', { href: '#/terms' }, 'Ketentuan Layanan'), '.')),

    section('Yang tidak pernah kami ambil',
      list(['Alamat rumah, NIK/KTP, lokasi real-time, password.', 'Isi SMS atau WhatsApp, data rekening, kontak pribadi pengguna lain.', 'Data dari database bocor atau dari perangkat orang lain tanpa izin.'])));

  return { title: 'Privacy Center', el, destroy() {} };
}
