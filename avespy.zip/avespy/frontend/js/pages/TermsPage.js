import { h } from '../utils/dom.js';

const li = (t) => h('li', {}, t);

export function TermsPage() {
  const el = h('article', { class: 'container page prose' },
    h('h1', {}, 'Ketentuan Layanan'),
    h('p', { class: 'lead' }, 'Dengan memakai Avespy Anda menyetujui ketentuan berikut.'),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Penggunaan yang diizinkan'),
      h('ul', { class: 'bullets' }, [
        li('Memeriksa nomor yang menghubungi Anda untuk keperluan keamanan dan verifikasi yang sah.'),
        li('Melaporkan nomor berdasarkan pengalaman pribadi secara jujur.'),
      ])),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Dilarang'),
      h('ul', { class: 'bullets' }, [
        li('Stalking, harassment, atau mencari tahu keberadaan dan aktivitas seseorang.'),
        li('Doxxing: menghimpun atau menyebarkan identitas atau data pribadi seseorang.'),
        li('Penipuan, termasuk memakai hasil pencarian untuk menargetkan korban.'),
        li('Laporan palsu, fitnah, atau laporan terkoordinasi untuk merusak nama nomor atau pemiliknya.'),
        li('Scraping, pencarian massal, enumerasi nomor berurutan, atau mengakali pembatasan dan CAPTCHA.'),
        li('Mencantumkan data pribadi (nama, email, tautan, rekening, NIK) dalam laporan.'),
      ])),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Batasan hasil'),
      h('p', {}, 'Hasil adalah indikasi berdasarkan data yang tersedia dan laporan komunitas. Hasil bukan identitas resmi pemilik nomor, bukan bukti hukum, dan dapat keliru. Anda bertanggung jawab atas keputusan yang Anda ambil.')),
    h('section', { class: 'prose-block' }, h('h2', {}, 'Penegakan'),
      h('p', {}, 'Kami mencatat kejadian penyalahgunaan, dapat memblokir akses secara otomatis, dan menghapus laporan yang melanggar. Pemilik nomor dapat meminta penghapusan informasinya lewat ', h('a', { href: '#/privacy' }, 'Privacy Center'), '.')));
  return { title: 'Ketentuan Layanan', el, destroy() {} };
}
