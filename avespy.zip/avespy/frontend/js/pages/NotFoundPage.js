import { h } from '../utils/dom.js';

export function NotFoundPage() {
  const el = h('section', { class: 'container page' },
    h('h1', {}, 'Halaman tidak ditemukan'),
    h('p', { class: 'lead' }, 'Alamat yang Anda buka tidak ada. Kembali ke beranda untuk mengecek nomor.'),
    h('a', { class: 'btn', href: '#/' }, 'Ke beranda'));
  return { title: 'Tidak ditemukan', el, destroy() {} };
}
