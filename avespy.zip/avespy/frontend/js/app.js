import { h } from './utils/dom.js';
import { startRouter } from './utils/router.js';
import { loadConfig } from './services/configService.js';
import { Navbar } from './components/Navbar.js';
import { Footer } from './components/Footer.js';
import { HomePage } from './pages/HomePage.js';
import { CheckPage } from './pages/CheckPage.js';
import { ReportsPage } from './pages/ReportsPage.js';
import { PrivacyPage } from './pages/PrivacyPage.js';
import { TermsPage } from './pages/TermsPage.js';
import { AboutPage } from './pages/AboutPage.js';
import { NotFoundPage } from './pages/NotFoundPage.js';

async function boot() {
  await loadConfig();
  const root = document.getElementById('app');
  const navbar = Navbar();
  const outlet = h('main', { id: 'main', class: 'main' });
  root.replaceChildren(navbar.el, outlet, Footer());

  startRouter({
    outlet,
    routes: {
      '/': HomePage,
      '/cek': CheckPage,
      '/laporan': ReportsPage,
      '/privacy': PrivacyPage,
      '/terms': TermsPage,
      '/tentang': AboutPage,
    },
    notFound: NotFoundPage,
    onNavigate: (path) => navbar.setActive(path),
  });
}

boot();
