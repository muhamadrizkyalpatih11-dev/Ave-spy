import { svg } from './dom.js';

const PATHS = {
  shield: 'M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6l7-3zM9 12l2 2 4-4',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4',
  flag: 'M5 21V4M5 4h11l-2 4 2 4H5',
  lock: 'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
  moon: 'M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z',
  sun: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5',
  check: 'M5 12l5 5 9-10',
  alert: 'M12 4l9 16H3L12 4zM12 10v4M12 17v.5',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18',
  phone: 'M6 3h4l2 5-2.5 1.5a11 11 0 0 0 5 5L16 12l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 4 6a2 2 0 0 1 2-3z',
  tower: 'M12 12v9M8 21h8M9 8a4 4 0 0 1 6 0M6.5 5.5a8 8 0 0 1 11 0M12 10.5v.5',
  tag: 'M3 12V4h8l10 10-8 8L3 12zM7.5 8h.01',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 7v5l3 2',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  eyeOff: 'M3 3l18 18M10.6 6.1A9 9 0 0 1 21 12a13 13 0 0 1-2.6 3.4M6.2 6.6A13 13 0 0 0 3 12s3.5 6 9 6a9 9 0 0 0 3-.5',
  users: 'M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20a6 6 0 0 1 12 0M17 11a3 3 0 1 0-1-5.8M21 20a6 6 0 0 0-4-5.6',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v6M12 7.5v.5',
  menu: 'M4 7h16M4 12h16M4 17h16',
  x: 'M6 6l12 12M18 6L6 18',
  chart: 'M5 20V10M12 20V4M19 20v-7',
  refresh: 'M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5',
  copy: 'M9 9h11v11H9zM5 15V4h11',
};

export function icon(name, size = 20) {
  return svg(
    'svg',
    {
      viewBox: '0 0 24 24', width: size, height: size, fill: 'none', stroke: 'currentColor',
      'stroke-width': 1.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true', focusable: 'false', class: 'icon',
    },
    svg('path', { d: PATHS[name] || PATHS.info }),
  );
}

/** Ikon kekuatan sinyal; batang bergerak saat class "is-busy" aktif pada induknya. */
export function signalBars() {
  const bars = [0, 1, 2, 3].map((i) =>
    svg('rect', { x: 3 + i * 5.5, y: 17 - (i + 1) * 4, width: 3.5, height: (i + 1) * 4 + 2, rx: 1.2, class: `bar bar-${i}` }),
  );
  return svg('svg', { viewBox: '0 0 24 24', width: 26, height: 26, fill: 'currentColor', 'aria-hidden': 'true', class: 'signal-bars' }, ...bars);
}
