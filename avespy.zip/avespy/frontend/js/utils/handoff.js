// Menyerahkan data antarhalaman lewat memori (tidak menaruh nomor telepon di URL atau storage).
let pending = null;
export const setHandoff = (value) => {
  pending = value;
};
export const takeHandoff = () => {
  const value = pending;
  pending = null;
  return value;
};
