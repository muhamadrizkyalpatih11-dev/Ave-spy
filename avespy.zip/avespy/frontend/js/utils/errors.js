export const UNAVAILABLE_MESSAGE = 'Layanan sedang tidak tersedia. Silakan coba lagi.';

/** Galat aplikasi dengan kode yang dapat diperiksa UI (mis. CAPTCHA_REQUIRED). */
export class AppError extends Error {
  constructor(code, message, status = 0) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.status = status;
  }
}

export const messageOf = (err) => (err instanceof AppError ? err.message : UNAVAILABLE_MESSAGE);
