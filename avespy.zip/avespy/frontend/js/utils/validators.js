export const EMPTY_NUMBER = 'Masukkan nomor telepon terlebih dahulu.';
export const INVALID_NUMBER = 'Nomor telepon tidak valid.';

/** Validasi ringan di sisi klien. Validasi resmi (E.164) tetap dilakukan server. */
export function validateNumberInput(value) {
  const text = String(value ?? '').trim();
  if (!text) return EMPTY_NUMBER;
  if (!/^\+?[\d\s().-]+$/.test(text)) return INVALID_NUMBER;
  const digits = text.replace(/\D/g, '');
  if (digits.length < 6 || digits.length > 15) return INVALID_NUMBER;
  return null;
}

export const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim());
