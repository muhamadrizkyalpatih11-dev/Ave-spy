export const currentPath = () => (location.hash.replace(/^#/, '') || '/').split('?')[0];
export const navigate = (path) => {
  location.hash = path;
};

/** Router berbasis hash: tidak membutuhkan konfigurasi fallback di server. */
export function startRouter({ outlet, routes, notFound, onNavigate }) {
  let current = null;
  let first = true;

  const render = () => {
    const path = currentPath();
    current?.destroy?.();
    current = (routes[path] || notFound)();
    outlet.replaceChildren(current.el);
    document.title = `${current.title} | Avespy`;
    window.scrollTo(0, 0);
    if (!first) {
      const heading = outlet.querySelector('h1');
      if (heading) {
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
      }
    }
    first = false;
    onNavigate?.(path);
  };

  window.addEventListener('hashchange', render);
  render();
}
