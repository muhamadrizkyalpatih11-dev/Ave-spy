export const CATEGORY_LABEL = {
  scam: 'Penipuan',
  spam: 'Spam',
  telemarketing: 'Telemarketing',
  pinjol: 'Pinjaman online',
  phishing: 'Phishing',
  robocall: 'Robocall',
  other: 'Lainnya',
};

export const CONFIDENCE_LABEL = { none: 'Belum ada data', low: 'Rendah', medium: 'Sedang', high: 'Tinggi' };

export const STATUS_LABEL = { pending: 'Menunggu', approved: 'Disetujui', rejected: 'Ditolak' };

const dateFmt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long' });
const dateTimeFmt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
const rtf = new Intl.RelativeTimeFormat('id-ID', { numeric: 'auto' });

export const formatDate = (iso) => (iso ? dateFmt.format(new Date(iso)) : '-');
export const formatDateTime = (iso) => (iso ? dateTimeFmt.format(new Date(iso)) : '-');

export function formatRelative(iso) {
  if (!iso) return '-';
  const days = Math.round((new Date(iso).getTime() - Date.now()) / 86_400_000);
  if (Math.abs(days) < 1) return 'hari ini';
  if (Math.abs(days) < 30) return rtf.format(days, 'day');
  if (Math.abs(days) < 365) return rtf.format(Math.round(days / 30), 'month');
  return rtf.format(Math.round(days / 365), 'year');
}

export const NA = 'DATA TIDAK TERSEDIA';
