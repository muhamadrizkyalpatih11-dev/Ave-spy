import { adminRequest, openRequest, publicRequest } from './httpClient.js';

const qs = (params) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params || {})) if (v !== undefined && v !== '' && v !== null) p.set(k, v);
  const s = p.toString();
  return s ? `?${s}` : '';
};

/** Satu-satunya tempat yang mengetahui URL backend. Komponen dan halaman tidak boleh memanggil fetch. */
export const api = {
  config: () => openRequest('GET', '/config'),
  captcha: () => openRequest('GET', '/captcha'),
  lookup: (payload) => publicRequest('POST', '/lookup', { body: payload }),
  reportsFor: (e164, page, captcha) =>
    publicRequest('GET', `/reports/${encodeURIComponent(e164)}${qs({ page })}`, {
      headers: captcha ? { 'X-Captcha-Token': captcha.token, ...(captcha.answer ? { 'X-Captcha-Answer': captcha.answer } : {}) } : {},
    }),
  createReport: (payload) => publicRequest('POST', '/reports', { body: payload }),
  deleteReport: (id, token) => publicRequest('DELETE', `/reports/${encodeURIComponent(id)}`, { body: { token } }),
  requestRemoval: (payload) => publicRequest('POST', '/removal-request', { body: payload }),
};

export const adminApi = {
  login: (email, password) => adminRequest('POST', '/auth/login', { email, password }),
  logout: () => adminRequest('POST', '/auth/logout', {}),
  me: () => adminRequest('GET', '/auth/me'),
  stats: () => adminRequest('GET', '/stats'),
  reports: (params) => adminRequest('GET', `/reports${qs(params)}`),
  moderateReport: (id, action, note) => adminRequest('PATCH', `/reports/${id}`, { action, note }),
  deleteReport: (id) => adminRequest('DELETE', `/reports/${id}`),
  removals: (params) => adminRequest('GET', `/removal-requests${qs(params)}`),
  handleRemoval: (id, action, note) => adminRequest('PATCH', `/removal-requests/${id}`, { action, note }),
  abuseEvents: (params) => adminRequest('GET', `/abuse-events${qs(params)}`),
  auditLogs: (params) => adminRequest('GET', `/audit-logs${qs(params)}`),
};
