import { AppError, UNAVAILABLE_MESSAGE } from '../utils/errors.js';

const BASE = '/api';
let sessionToken = null;
let sessionPromise = null;

function readCookie(name) {
  const match = document.cookie.split('; ').find((c) => c.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.split('=')[1]) : null;
}

async function raw(method, path, { body, headers = {}, credentials } = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), Accept: 'application/json', ...headers },
      body: body ? JSON.stringify(body) : undefined,
      credentials: credentials || 'same-origin',
    });
  } catch {
    throw new AppError('UNAVAILABLE', UNAVAILABLE_MESSAGE);
  }
  let json = null;
  try {
    json = await res.json();
  } catch {
    /* respons non-JSON */
  }
  if (!res.ok) {
    const code = json?.error?.code || 'UNAVAILABLE';
    const message = res.status >= 500 || !json?.error?.message ? UNAVAILABLE_MESSAGE : json.error.message;
    throw new AppError(code, message, res.status);
  }
  return json;
}

async function ensureSession(force = false) {
  if (sessionToken && !force) return sessionToken;
  if (!sessionPromise) {
    sessionPromise = raw('POST', '/session')
      .then((json) => {
        sessionToken = json.data.token;
        return sessionToken;
      })
      .finally(() => {
        sessionPromise = null;
      });
  }
  return sessionPromise;
}

/** Endpoint publik: otomatis membawa token sesi anonim dan memperbaruinya bila kedaluwarsa. */
export async function publicRequest(method, path, { body, headers } = {}) {
  const attempt = async (force) => {
    const token = await ensureSession(force);
    return raw(method, path, { body, headers: { ...headers, Authorization: `Bearer ${token}` } });
  };
  try {
    return await attempt(false);
  } catch (err) {
    if (err.code === 'SESSION_EXPIRED' || err.code === 'UNAUTHENTICATED') return attempt(true);
    throw err;
  }
}

/** Endpoint bootstrap yang tidak membutuhkan sesi (config, captcha). */
export const openRequest = (method, path) => raw(method, path);

/** Endpoint admin: cookie httpOnly + header CSRF (double-submit). */
export function adminRequest(method, path, body) {
  const csrf = readCookie('avespy_csrf');
  return raw(method, `/admin${path}`, { body, headers: csrf ? { 'X-CSRF-Token': csrf } : {} });
}
