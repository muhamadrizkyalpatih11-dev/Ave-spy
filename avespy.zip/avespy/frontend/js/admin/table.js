import { h } from '../utils/dom.js';

/** Tabel generik. columns: [{ label, render(row) -> Node|string }] */
export function DataTable(columns, rows, emptyText = 'Tidak ada data.') {
  if (!rows.length) return h('p', { class: 'muted pad' }, emptyText);
  return h('div', { class: 'table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Tabel data' },
    h('table', { class: 'table' },
      h('thead', {}, h('tr', {}, columns.map((c) => h('th', { scope: 'col' }, c.label)))),
      h('tbody', {}, rows.map((r) => h('tr', {}, columns.map((c) => h('td', { 'data-label': c.label }, c.render(r))))))));
}

export function Pager({ page, pageSize, total }, onPage) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  return h('div', { class: 'pager' },
    h('button', { class: 'btn-ghost', type: 'button', disabled: page <= 1, onClick: () => onPage(page - 1) }, 'Sebelumnya'),
    h('span', { class: 'muted' }, `Halaman ${page} dari ${pages} (${total} data)`),
    h('button', { class: 'btn-ghost', type: 'button', disabled: page >= pages, onClick: () => onPage(page + 1) }, 'Berikutnya'));
}
