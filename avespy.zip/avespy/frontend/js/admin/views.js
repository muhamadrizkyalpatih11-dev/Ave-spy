import { h } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { Notice } from '../components/Notice.js';
import { adminService } from '../services/adminService.js';
import { messageOf } from '../utils/errors.js';
import { CATEGORY_LABEL, STATUS_LABEL, formatDateTime } from '../utils/format.js';
import { DataTable, Pager } from './table.js';

const statusChip = (s) => h('span', { class: `chip status-${s}` }, STATUS_LABEL[s] || s);
const catChip = (c) => h('span', { class: 'chip' }, CATEGORY_LABEL[c] || c);

/** Membungkus pemuatan data: tampilkan status memuat dan galat dengan pesan yang jelas. */
async function loadInto(host, loader) {
  host.replaceChildren(h('p', { class: 'muted pad', role: 'status' }, 'Memuat...'));
  try {
    host.replaceChildren(await loader());
  } catch (err) {
    host.replaceChildren(Notice('error', messageOf(err)));
  }
}

// ---------- Ringkasan ----------
export function OverviewView() {
  const host = h('div');
  const bars = (series) => {
    const max = Math.max(1, ...series.map((s) => s.n));
    return h('ul', { class: 'spark', 'aria-label': 'Pencarian 14 hari terakhir' },
      series.map((s) => {
        const b = h('span', { class: 'spark-bar' });
        b.style.setProperty('--h', `${Math.max(4, Math.round((s.n / max) * 100))}%`);
        return h('li', { title: `${s.day}: ${s.n}` }, b, h('small', {}, s.day.slice(8)));
      }));
  };
  const stat = (label, value) => h('div', { class: 'stat card' }, h('p', { class: 'stat-n' }, String(value)), h('p', { class: 'muted' }, label));

  loadInto(host, async () => {
    const s = await adminService.stats();
    const rep = s.reportsByStatus;
    return h('div', { class: 'stack' },
      h('div', { class: 'stats' },
        stat('Pencarian hari ini', s.lookupsToday), stat('Pencarian 7 hari', s.lookups7d),
        stat('Laporan menunggu', rep.pending || 0), stat('Permintaan hapus data', s.pendingRemovals)),
      h('div', { class: 'card' }, h('h2', { class: 'h3' }, 'Pencarian 14 hari terakhir'), s.lookupSeries.length ? bars(s.lookupSeries) : h('p', { class: 'muted' }, 'Belum ada data.')),
      h('div', { class: 'two-col' },
        h('div', { class: 'card' }, h('h2', { class: 'h3' }, 'Negara teratas (7 hari)'),
          s.topCountries.length ? h('ul', { class: 'plain-list' }, s.topCountries.map((c) => h('li', {}, `${c.country}: ${c.n}`))) : h('p', { class: 'muted' }, 'Belum ada data.')),
        h('div', { class: 'card' }, h('h2', { class: 'h3' }, 'Abuse 24 jam terakhir'),
          s.abuseLast24h.length ? h('ul', { class: 'plain-list' }, s.abuseLast24h.map((a) => h('li', {}, `${a.type}: ${a.n}`))) : h('p', { class: 'muted' }, 'Tidak ada kejadian.'))));
  });
  return host;
}

// ---------- Laporan ----------
export function ReportsView({ spamOnly = false } = {}) {
  const host = h('div', { class: 'stack' });
  const filters = { status: spamOnly ? 'approved' : 'pending', category: '', page: 1 };
  const feedback = h('div', { 'aria-live': 'polite' });
  const table = h('div');

  const select = (label, key, options) => {
    const el = h('select', { class: 'select', 'aria-label': label },
      options.map(([v, t]) => h('option', { value: v, selected: filters[key] === v }, t)));
    el.addEventListener('change', () => { filters[key] = el.value; filters.page = 1; load(); });
    return el;
  };

  async function act(fn, okMsg) {
    feedback.replaceChildren();
    try {
      await fn();
      feedback.replaceChildren(Notice('success', okMsg));
      load();
    } catch (err) {
      feedback.replaceChildren(Notice('error', messageOf(err)));
    }
  }

  function load() {
    const params = { status: filters.status, page: filters.page };
    if (spamOnly) params.category = filters.category || undefined;
    else if (filters.category) params.category = filters.category;
    loadInto(table, async () => {
      const data = await adminService.reports(params);
      const cols = [
        { label: 'ID', render: (r) => String(r.id) },
        { label: 'Nomor', render: (r) => h('span', { class: 'mono' }, r.number_e164) },
        { label: 'Kategori', render: (r) => catChip(r.category) },
        { label: 'Deskripsi', render: (r) => r.description || h('span', { class: 'muted' }, '-') },
        { label: 'Status', render: (r) => statusChip(r.status) },
        { label: 'Dikirim', render: (r) => formatDateTime(r.created_at) },
        {
          label: 'Aksi',
          render: (r) => h('div', { class: 'actions' },
            r.status !== 'approved' ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => act(() => adminService.moderateReport(r.id, 'approve'), `Laporan ${r.id} disetujui.`) }, 'Setujui') : null,
            r.status !== 'rejected' ? h('button', { class: 'btn btn-sm btn-secondary', type: 'button', onClick: () => act(() => adminService.moderateReport(r.id, 'reject'), `Laporan ${r.id} ditolak.`) }, 'Tolak') : null,
            h('button', {
              class: 'btn btn-sm btn-danger', type: 'button',
              onClick: () => { if (confirm(`Hapus permanen laporan ${r.id}? Aksi ini tidak dapat dibatalkan.`)) act(() => adminService.deleteReport(r.id), `Laporan ${r.id} dihapus.`); },
            }, icon('trash', 14), 'Hapus')),
        },
      ];
      return h('div', {}, DataTable(cols, data.items, 'Tidak ada laporan pada filter ini.'), Pager(data, (p) => { filters.page = p; load(); }));
    });
  }

  const statusOpts = [['pending', 'Menunggu'], ['approved', 'Disetujui'], ['rejected', 'Ditolak'], ['', 'Semua status']];
  const catOpts = spamOnly
    ? [['', 'Spam dan penipuan'], ['scam', 'Penipuan'], ['spam', 'Spam'], ['phishing', 'Phishing'], ['robocall', 'Robocall'], ['telemarketing', 'Telemarketing'], ['pinjol', 'Pinjaman online']]
    : [['', 'Semua kategori'], ...Object.entries(CATEGORY_LABEL)];
  host.append(h('div', { class: 'toolbar' }, select('Filter status', 'status', statusOpts), select('Filter kategori', 'category', catOpts)), feedback, table);
  load();
  return host;
}

// ---------- Penghapusan data ----------
export function RemovalsView() {
  const host = h('div', { class: 'stack' });
  const feedback = h('div', { 'aria-live': 'polite' });
  const table = h('div');
  let page = 1;
  let status = 'pending';

  async function act(id, action) {
    const note = prompt(action === 'approve'
      ? 'Catatan verifikasi kepemilikan nomor (wajib diisi sebelum menyetujui):'
      : 'Alasan penolakan (opsional):') || '';
    if (action === 'approve' && !note.trim()) { feedback.replaceChildren(Notice('error', 'Catatan verifikasi wajib diisi sebelum menyetujui.')); return; }
    try {
      await adminService.handleRemoval(id, action, note.trim() || undefined);
      feedback.replaceChildren(Notice('success', action === 'approve' ? 'Disetujui: laporan dihapus dan nomor disembunyikan.' : 'Permintaan ditolak.'));
      load();
    } catch (err) {
      feedback.replaceChildren(Notice('error', messageOf(err)));
    }
  }

  function load() {
    loadInto(table, async () => {
      const data = await adminService.removals({ status, page });
      const cols = [
        { label: 'Ref', render: (r) => `RM-${r.id}` },
        { label: 'Nomor', render: (r) => (r.number_e164 ? h('span', { class: 'mono' }, r.number_e164) : h('span', { class: 'muted' }, 'dihapus setelah diproses')) },
        { label: 'Email', render: (r) => r.contact_email || h('span', { class: 'muted' }, '-') },
        { label: 'Alasan', render: (r) => r.reason || h('span', { class: 'muted' }, '-') },
        { label: 'Status', render: (r) => statusChip(r.status) },
        { label: 'Diajukan', render: (r) => formatDateTime(r.created_at) },
        {
          label: 'Aksi',
          render: (r) => (r.status === 'pending'
            ? h('div', { class: 'actions' },
              h('button', { class: 'btn btn-sm', type: 'button', onClick: () => act(r.id, 'approve') }, 'Setujui'),
              h('button', { class: 'btn btn-sm btn-secondary', type: 'button', onClick: () => act(r.id, 'reject') }, 'Tolak'))
            : h('span', { class: 'muted' }, r.note || '-')),
        },
      ];
      return h('div', {}, DataTable(cols, data.items, 'Tidak ada permintaan.'), Pager(data, (p) => { page = p; load(); }));
    });
  }

  const sel = h('select', { class: 'select', 'aria-label': 'Filter status' },
    [['pending', 'Menunggu'], ['approved', 'Disetujui'], ['rejected', 'Ditolak'], ['', 'Semua']].map(([v, t]) => h('option', { value: v }, t)));
  sel.addEventListener('change', () => { status = sel.value; page = 1; load(); });
  host.append(
    h('p', { class: 'muted' }, 'Verifikasi kepemilikan nomor (mis. tautan verifikasi ke email atau OTP lewat kanal resmi) sebelum menyetujui. Persetujuan menghapus semua laporan nomor tersebut.'),
    h('div', { class: 'toolbar' }, sel), feedback, table);
  load();
  return host;
}

// ---------- Abuse ----------
export function AbuseView() {
  const host = h('div');
  let page = 1;
  const load = () => loadInto(host, async () => {
    const data = await adminService.abuseEvents({ page });
    return h('div', {}, DataTable([
      { label: 'Waktu', render: (r) => formatDateTime(r.created_at) },
      { label: 'Jenis', render: (r) => h('span', { class: 'chip' }, r.type) },
      { label: 'IP (hash)', render: (r) => h('span', { class: 'mono' }, r.ip_hash || '-') },
      { label: 'Detail', render: (r) => (r.detail ? JSON.stringify(r.detail) : '-') },
    ], data.items, 'Belum ada kejadian abuse.'), Pager(data, (p) => { page = p; load(); }));
  });
  load();
  return host;
}

// ---------- Audit ----------
export function AuditView() {
  const host = h('div');
  let page = 1;
  const load = () => loadInto(host, async () => {
    const data = await adminService.auditLogs({ page });
    return h('div', {}, DataTable([
      { label: 'Waktu', render: (r) => formatDateTime(r.created_at) },
      { label: 'Aktor', render: (r) => `${r.actor_type}${r.actor_id ? ` #${r.actor_id}` : ''}` },
      { label: 'Aksi', render: (r) => h('span', { class: 'mono' }, r.action) },
      { label: 'Target', render: (r) => r.target || '-' },
    ], data.items, 'Belum ada log.'), Pager(data, (p) => { page = p; load(); }));
  });
  load();
  return host;
}
