import { h, nextId } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { Notice } from '../components/Notice.js';
import { adminService } from '../services/adminService.js';
import { messageOf } from '../utils/errors.js';
import { currentTheme, toggleTheme } from '../utils/theme.js';
import { AbuseView, AuditView, OverviewView, RemovalsView, ReportsView } from './views.js';

const root = document.getElementById('admin-app');

function LoginView(onSuccess) {
  const emailId = nextId('em');
  const passId = nextId('pw');
  const email = h('input', { id: emailId, class: 'input', type: 'email', autocomplete: 'username', required: true });
  const pass = h('input', { id: passId, class: 'input', type: 'password', autocomplete: 'current-password', required: true });
  const out = h('div', { 'aria-live': 'polite' });
  const btn = h('button', { class: 'btn', type: 'submit' }, 'Masuk');
  const form = h('form', { class: 'card login', novalidate: true },
    h('div', { class: 'brand' }, icon('shield', 26), h('span', {}, 'AVESPY')),
    h('h1', { class: 'h2' }, 'Masuk moderator'),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: emailId }, 'Email'), email),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: passId }, 'Password'), pass),
    out, btn);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    out.replaceChildren();
    btn.disabled = true;
    try {
      onSuccess(await adminService.login(email.value, pass.value));
    } catch (err) {
      out.replaceChildren(Notice('error', messageOf(err)));
      pass.value = '';
    } finally {
      btn.disabled = false;
    }
  });
  return h('main', { class: 'login-wrap' }, form);
}

function Dashboard(admin, onLogout) {
  const tabs = [
    ['ringkasan', 'Ringkasan', () => OverviewView()],
    ['laporan', 'Laporan', () => ReportsView()],
    ['spam', 'Laporan spam', () => ReportsView({ spamOnly: true })],
    ['hapus', 'Penghapusan data', () => RemovalsView()],
    ['abuse', 'Abuse dan rate limit', () => AbuseView()],
  ];
  if (admin.role === 'admin') tabs.push(['audit', 'Audit log', () => AuditView()]);

  const panel = h('div', { id: 'admin-panel', role: 'tabpanel', tabindex: '-1' });
  const nav = h('nav', { class: 'admin-tabs', 'aria-label': 'Menu moderasi' });

  function show(key) {
    const tab = tabs.find((t) => t[0] === key) || tabs[0];
    nav.querySelectorAll('button').forEach((b) => b.setAttribute('aria-current', b.dataset.key === tab[0] ? 'page' : 'false'));
    panel.replaceChildren(h('h1', { class: 'h2' }, tab[1]), tab[2]());
  }
  tabs.forEach(([key, label]) => nav.append(h('button', { class: 'tab', type: 'button', 'data-key': key, onClick: () => { location.hash = key; } }, label)));
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));

  const themeBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Ganti mode tampilan' }, icon(currentTheme() === 'dark' ? 'sun' : 'moon'));
  themeBtn.addEventListener('click', () => { toggleTheme(); themeBtn.replaceChildren(icon(currentTheme() === 'dark' ? 'sun' : 'moon')); });
  const logout = h('button', { class: 'btn btn-secondary btn-sm', type: 'button' }, 'Keluar');
  logout.addEventListener('click', async () => {
    try { await adminService.logout(); } catch { /* sesi mungkin sudah habis */ }
    onLogout();
  });

  const el = h('div', { class: 'admin-shell' },
    h('header', { class: 'site-header' }, h('div', { class: 'container header-inner' },
      h('div', { class: 'brand' }, icon('shield', 26), h('span', {}, 'AVESPY Moderasi')),
      h('div', { class: 'header-actions' }, h('span', { class: 'muted small' }, `${admin.email} (${admin.role})`), themeBtn, logout))),
    h('div', { class: 'container admin-main' }, nav, panel));
  show(location.hash.slice(1));
  return el;
}

async function start() {
  const enter = (admin) => root.replaceChildren(Dashboard(admin, () => root.replaceChildren(LoginView(enter))));
  try {
    enter(await adminService.currentAdmin());
  } catch {
    root.replaceChildren(LoginView(enter));
  }
}
start();
