import { h, nextId } from '../utils/dom.js';
import { Notice } from './Notice.js';
import { deleteMyReport } from '../services/reportService.js';
import { messageOf } from '../utils/errors.js';

export function DeleteReportForm() {
  const idField = nextId('rid');
  const tokField = nextId('rtok');
  const id = h('input', { id: idField, class: 'input', inputmode: 'numeric', autocomplete: 'off' });
  const token = h('input', { id: tokField, class: 'input', autocomplete: 'off', spellcheck: 'false' });
  const out = h('div', { 'aria-live': 'polite' });
  const button = h('button', { class: 'btn btn-secondary', type: 'submit' }, 'Hapus laporan saya');
  const form = h('form', { class: 'card form', novalidate: true },
    h('h2', {}, 'Hapus laporan saya'),
    h('p', { class: 'muted' }, 'Masukkan ID dan token yang Anda terima saat mengirim laporan.'),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: idField }, 'ID laporan'), id),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: tokField }, 'Token penghapusan'), token),
    out, h('div', { class: 'row-end' }, button));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    out.replaceChildren();
    button.disabled = true;
    try {
      await deleteMyReport({ id: id.value, token: token.value });
      out.replaceChildren(Notice('success', 'Laporan dihapus permanen.'));
      form.reset();
    } catch (err) {
      out.replaceChildren(Notice('error', messageOf(err)));
    } finally {
      button.disabled = false;
    }
  });
  return { el: form };
}
