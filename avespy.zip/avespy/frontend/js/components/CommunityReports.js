import { h } from '../utils/dom.js';
import { PhoneField } from './PhoneField.js';
import { ReportList } from './ReportList.js';
import { Notice } from './Notice.js';
import { runGated } from './CaptchaGate.js';
import { checkNumber, listCommunityReports } from '../services/lookupService.js';
import { messageOf } from '../utils/errors.js';

/** Melihat laporan komunitas (yang sudah disetujui) untuk SATU nomor. Tidak ada pencarian massal. */
export function CommunityReports() {
  const phone = PhoneField({ label: 'Nomor yang ingin dilihat laporannya' });
  const gate = h('div');
  const out = h('div', { 'aria-live': 'polite' });
  const button = h('button', { class: 'btn btn-secondary', type: 'submit' }, 'Lihat laporan');
  const form = h('form', { class: 'card form', novalidate: true },
    h('h2', {}, 'Lihat laporan komunitas'), phone.el, gate, h('div', { class: 'row-end' }, button), out);

  let e164 = null;

  async function load(page) {
    const data = await listCommunityReports({ e164, page });
    const pages = Math.max(1, Math.ceil(data.total / data.pageSize));
    const prev = h('button', { class: 'btn-ghost', type: 'button', disabled: page <= 1, onClick: () => show(page - 1) }, 'Sebelumnya');
    const next = h('button', { class: 'btn-ghost', type: 'button', disabled: page >= pages, onClick: () => show(page + 1) }, 'Berikutnya');
    out.replaceChildren(
      data.suppressed
        ? Notice('info', 'Informasi untuk nomor ini disembunyikan atas permintaan pemiliknya.')
        : h('div', {}, h('p', { class: 'muted' }, `${data.total} laporan disetujui`), ReportList(data.reports),
          data.total > data.pageSize ? h('div', { class: 'pager' }, prev, h('span', { class: 'muted' }, `Halaman ${page} dari ${pages}`), next) : null));
  }

  async function show(page) {
    try {
      await load(page);
    } catch (err) {
      out.replaceChildren(Notice('error', messageOf(err)));
    }
  }

  async function submit(value) {
    phone.setError(null);
    out.replaceChildren();
    gate.replaceChildren();
    button.disabled = true;
    try {
      const data = await runGated((captcha) => checkNumber({ ...value, captcha }), gate);
      e164 = data.number.e164;
      await load(1);
    } catch (err) {
      const msg = messageOf(err);
      if (err.code === 'VALIDATION_ERROR' || err.code === 'INVALID_NUMBER') phone.setError(msg);
      else out.replaceChildren(Notice('error', msg));
    } finally {
      button.disabled = false;
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    submit(phone.getValue());
  });

  return { el: form, run: (v) => { phone.setValue(v); submit(v); } };
}
