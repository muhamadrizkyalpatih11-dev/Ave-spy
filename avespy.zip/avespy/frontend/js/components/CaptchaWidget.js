import { h, nextId } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { captchaProvider, fetchChallenge } from '../services/captchaService.js';

let turnstileLoader = null;
function loadTurnstile() {
  if (window.turnstile) return Promise.resolve(window.turnstile);
  if (!turnstileLoader) {
    turnstileLoader = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      s.async = true;
      s.onload = () => resolve(window.turnstile);
      s.onerror = () => reject(new Error('turnstile'));
      document.head.append(s);
    });
  }
  return turnstileLoader;
}

/**
 * Widget CAPTCHA. Mendukung CAPTCHA bawaan (soal penjumlahan bertanda tangan server)
 * dan Cloudflare Turnstile, sesuai konfigurasi server.
 * getValue() -> { token, answer? } atau null bila belum diisi.
 */
export function CaptchaWidget() {
  const { provider, siteKey } = captchaProvider();
  const root = h('div', { class: 'captcha' });
  let token = null;
  let widgetId = null;
  const input = h('input', { class: 'input', id: nextId('captcha'), inputmode: 'numeric', autocomplete: 'off', maxlength: '3', 'aria-describedby': undefined });
  const question = h('span', { class: 'captcha-q' }, 'Memuat verifikasi...');

  async function refresh() {
    input.value = '';
    token = null;
    if (provider === 'turnstile') {
      try {
        const ts = await loadTurnstile();
        if (widgetId !== null) ts.reset(widgetId);
      } catch {
        question.textContent = 'Verifikasi tidak dapat dimuat. Muat ulang halaman.';
      }
      return;
    }
    try {
      const c = await fetchChallenge();
      token = c.token;
      question.textContent = c.question;
    } catch {
      question.textContent = 'Verifikasi tidak tersedia. Coba lagi.';
    }
  }

  if (provider === 'turnstile') {
    const holder = h('div', { class: 'captcha-turnstile' });
    root.append(h('p', { class: 'field-label' }, 'Verifikasi keamanan'), holder);
    loadTurnstile()
      .then((ts) => {
        widgetId = ts.render(holder, {
          sitekey: siteKey,
          callback: (t) => { token = t; },
          'expired-callback': () => { token = null; },
        });
      })
      .catch(() => { holder.textContent = 'Verifikasi tidak dapat dimuat. Muat ulang halaman.'; });
  } else {
    input.setAttribute('aria-label', 'Jawaban verifikasi keamanan');
    root.append(
      h('p', { class: 'field-label' }, 'Verifikasi keamanan'),
      h('div', { class: 'captcha-row' }, question, input,
        h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Ganti soal', onClick: refresh }, icon('refresh', 18))));
    refresh();
  }

  return {
    el: root,
    refresh,
    getValue() {
      if (!token) return null;
      if (provider === 'turnstile') return { token };
      const answer = input.value.trim();
      return answer ? { token, answer } : null;
    },
    focus: () => input.focus(),
  };
}
