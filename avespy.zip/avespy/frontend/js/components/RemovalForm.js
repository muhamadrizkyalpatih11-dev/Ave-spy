import { h, nextId } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { PhoneField } from './PhoneField.js';
import { CaptchaWidget } from './CaptchaWidget.js';
import { Notice } from './Notice.js';
import { requestDataRemoval } from '../services/removalService.js';
import { messageOf } from '../utils/errors.js';

export function RemovalForm() {
  const phone = PhoneField({ label: 'Nomor yang informasinya ingin dihapus' });
  const captcha = CaptchaWidget();
  const emailId = nextId('email');
  const email = h('input', { id: emailId, class: 'input', type: 'email', autocomplete: 'email', maxlength: '200' });
  const reasonId = nextId('reason');
  const reason = h('textarea', { id: reasonId, class: 'textarea', rows: '3', maxlength: '500' });
  const consentId = nextId('rc');
  const consent = h('input', { type: 'checkbox', id: consentId });
  const feedback = h('div', { 'aria-live': 'polite' });
  const submit = h('button', { class: 'btn', type: 'submit' }, icon('trash', 18), 'Request Data Removal');

  const form = h('form', { class: 'card form', novalidate: true, id: 'removal' },
    h('h3', {}, 'Request Data Removal'),
    h('p', { class: 'muted' }, 'Untuk pemilik nomor atau perwakilan resminya. Kami memverifikasi kepemilikan sebelum menyembunyikan informasi dan menghapus laporan untuk nomor tersebut.'),
    phone.el,
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: emailId }, 'Email kontak'), email,
      h('p', { class: 'muted small' }, 'Dipakai hanya untuk verifikasi. Dihapus 30 hari setelah permintaan selesai.')),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: reasonId }, 'Alasan (opsional)'), reason),
    h('div', { class: 'field check' }, consent, h('label', { for: consentId }, 'Saya pemilik nomor ini atau perwakilan yang sah.')),
    captcha.el, feedback, h('div', { class: 'row-end' }, submit));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    phone.setError(null);
    feedback.replaceChildren();
    submit.disabled = true;
    try {
      const { region, number } = phone.getValue();
      const res = await requestDataRemoval({ region, number, email: email.value, reason: reason.value, consent: consent.checked, captcha: captcha.getValue() });
      feedback.replaceChildren(Notice('success', `${res.message} Nomor referensi: ${res.reference}.`));
      form.reset();
    } catch (err) {
      const msg = messageOf(err);
      if (err.code === 'VALIDATION_ERROR' && /telepon/i.test(msg)) phone.setError(msg);
      else feedback.replaceChildren(Notice('error', msg));
    } finally {
      captcha.refresh();
      submit.disabled = false;
    }
  });

  return { el: form };
}
