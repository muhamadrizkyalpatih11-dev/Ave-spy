import { h, nextId } from '../utils/dom.js';
import { getConfig } from '../services/configService.js';

/** Kolom nomor telepon: pilihan kode negara + input. Nilai dikirim apa adanya; normalisasi E.164 dilakukan server. */
export function PhoneField({ label = 'Nomor telepon', large = false, placeholder = 'Masukkan nomor telepon' } = {}) {
  const { regions } = getConfig();
  const selectId = nextId('region');
  const inputId = nextId('phone');
  const errorId = nextId('phone-err');

  const select = h('select', { id: selectId, class: 'region-select', 'aria-label': 'Kode negara' },
    regions.map((r) => h('option', { value: r.code, selected: r.code === 'ID', title: r.name || r.code }, `+${r.callingCode} ${r.code}`)));

  const input = h('input', {
    id: inputId, class: 'phone-input', type: 'tel', inputmode: 'tel', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false',
    placeholder, maxlength: '24', 'aria-describedby': errorId,
  });
  const error = h('p', { id: errorId, class: 'field-error', role: 'alert', hidden: true });

  const el = h('div', { class: `field phone-field${large ? ' is-large' : ''}` },
    h('label', { class: large ? 'sr-only' : 'field-label', for: inputId }, label),
    h('div', { class: 'phone-row' }, select, input),
    error);

  return {
    el,
    input,
    getValue: () => ({ region: select.value, number: input.value }),
    setValue({ region, number }) {
      if (region) select.value = region;
      input.value = number ?? '';
    },
    setError(message) {
      error.textContent = message || '';
      error.hidden = !message;
      input.setAttribute('aria-invalid', message ? 'true' : 'false');
    },
    focus: () => input.focus(),
  };
}
