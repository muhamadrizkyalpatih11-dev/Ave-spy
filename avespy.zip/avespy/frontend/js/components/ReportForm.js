import { h, nextId } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { PhoneField } from './PhoneField.js';
import { CaptchaWidget } from './CaptchaWidget.js';
import { Notice } from './Notice.js';
import { CATEGORY_LABEL, } from '../utils/format.js';
import { submitReport } from '../services/reportService.js';
import { messageOf } from '../utils/errors.js';

const TAGS = ['sales', 'spam', 'kurir', 'customer service', 'penagihan', 'survei'];
const MAX = 280;

export function ReportForm({ initial } = {}) {
  const phone = PhoneField({ label: 'Nomor yang dilaporkan' });
  if (initial) phone.setValue(initial);
  const captcha = CaptchaWidget();
  const feedback = h('div', { 'aria-live': 'polite' });
  const groupName = nextId('cat');

  const categories = Object.entries(CATEGORY_LABEL).map(([value, label]) => {
    const id = nextId('c');
    return h('div', { class: 'choice' },
      h('input', { type: 'radio', name: groupName, id, value }),
      h('label', { for: id }, label));
  });

  const tagId = nextId('tag');
  const tagSelect = h('select', { id: tagId, class: 'select' }, h('option', { value: '' }, 'Tanpa tag'), TAGS.map((t) => h('option', { value: t }, t)));

  const descId = nextId('desc');
  const counter = h('span', { class: 'muted small', id: nextId('count') }, `0/${MAX}`);
  const desc = h('textarea', { id: descId, class: 'textarea', rows: '3', maxlength: String(MAX), 'aria-describedby': counter.id });
  desc.addEventListener('input', () => { counter.textContent = `${desc.value.length}/${MAX}`; });

  const consentId = nextId('consent');
  const consent = h('input', { type: 'checkbox', id: consentId });
  const submit = h('button', { class: 'btn', type: 'submit' }, icon('flag', 18), 'Kirim laporan');

  const form = h('form', { class: 'card form', novalidate: true },
    h('h2', {}, 'Laporkan nomor'),
    phone.el,
    h('fieldset', { class: 'field' },
      h('legend', { class: 'field-label' }, 'Kategori'),
      h('div', { class: 'choices' }, categories)),
    h('div', { class: 'field' }, h('label', { class: 'field-label', for: tagId }, 'Tag komunitas (opsional)'), tagSelect,
      h('p', { class: 'muted small' }, 'Pilih dari daftar. Tag bukan identitas pemilik nomor dan baru tampil bila dipakai beberapa pelapor.')),
    h('div', { class: 'field' },
      h('label', { class: 'field-label', for: descId }, 'Deskripsi singkat (opsional)'), desc, counter,
      h('p', { class: 'muted small' }, 'Jangan menulis nama, email, tautan, nomor rekening, atau NIK. Laporan yang memuat data pribadi ditolak.')),
    h('div', { class: 'field check' }, consent,
      h('label', { for: consentId }, 'Laporan ini berdasarkan pengalaman saya sendiri, jujur, dan saya memahami laporan ditinjau moderator.')),
    captcha.el,
    feedback,
    h('div', { class: 'row-end' }, submit));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    phone.setError(null);
    feedback.replaceChildren();
    const { region, number } = phone.getValue();
    const category = form.querySelector(`input[name="${groupName}"]:checked`)?.value;
    const value = captcha.getValue();
    submit.disabled = true;
    try {
      const result = await submitReport({
        region, number, category, tag: tagSelect.value, description: desc.value, consent: consent.checked,
        captcha: value,
      });
      showSuccess(result);
    } catch (err) {
      const msg = messageOf(err);
      if (err.code === 'VALIDATION_ERROR' && /telepon/i.test(msg)) phone.setError(msg);
      else feedback.replaceChildren(Notice('error', msg));
      captcha.refresh();
    } finally {
      submit.disabled = false;
    }
  });

  function showSuccess(result) {
    const tokenBox = h('code', { class: 'token' }, result.deleteToken);
    const copy = h('button', { class: 'btn-ghost', type: 'button' }, icon('copy', 18), 'Salin token');
    copy.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(result.deleteToken);
        copy.replaceChildren(icon('check', 18), 'Tersalin');
      } catch {
        copy.textContent = 'Salin manual token di atas';
      }
    });
    const done = h('div', { class: 'card success-panel', role: 'status' },
      h('h2', {}, 'Laporan diterima'),
      h('p', {}, result.message),
      h('p', {}, 'Simpan ID dan token berikut. Anda membutuhkannya untuk menghapus laporan ini. Token hanya ditampilkan sekali.'),
      h('dl', { class: 'info-list' },
        h('div', { class: 'info-row' }, h('dt', {}, 'ID laporan'), h('dd', {}, String(result.id))),
        h('div', { class: 'info-row' }, h('dt', {}, 'Token hapus'), h('dd', {}, tokenBox))),
      copy);
    form.replaceWith(done);
    done.querySelector('h2').setAttribute('tabindex', '-1');
    done.querySelector('h2').focus();
  }

  return { el: form, setInitial: (v) => phone.setValue(v) };
}
