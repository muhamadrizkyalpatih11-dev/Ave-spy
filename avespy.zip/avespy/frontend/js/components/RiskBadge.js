import { h } from '../utils/dom.js';

const MAP = {
  low: ['ok', 'Risiko Rendah'],
  caution: ['warn', 'Perlu Waspada'],
  spam: ['bad', 'Terindikasi Spam'],
  unknown: ['neutral', 'Belum Ada Laporan'],
  hidden: ['neutral', 'Disembunyikan'],
};

export function RiskBadge(status) {
  const [tone, label] = MAP[status] || MAP.unknown;
  return h('span', { class: `badge badge-${tone}` }, h('span', { class: 'badge-dot', 'aria-hidden': 'true' }), label);
}
