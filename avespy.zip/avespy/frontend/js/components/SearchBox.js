import { h } from '../utils/dom.js';
import { icon, signalBars } from '../utils/icons.js';
import { PhoneField } from './PhoneField.js';

/** Kotak pencarian besar bergaya layar caller ID. Hanya mengumpulkan input; logika ada di halaman. */
export function SearchBox({ onSubmit, hint = true }) {
  const field = PhoneField({ large: true, label: 'Nomor telepon yang akan diperiksa' });
  const button = h('button', { class: 'btn btn-lg', type: 'submit' }, icon('search', 20), 'CEK NOMOR');
  const bars = h('span', { class: 'search-signal' }, signalBars());

  const form = h('form', { class: 'search-box', novalidate: true, 'aria-label': 'Cek nomor telepon' },
    h('div', { class: 'search-main' }, bars, field.el),
    button);

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (button.disabled) return;
    onSubmit(field.getValue());
  });

  const el = h('div', { class: 'search-wrap' }, form,
    hint ? h('p', { class: 'search-hint' }, 'Gunakan Avespy hanya untuk tujuan keamanan dan verifikasi yang sah.') : null);

  return {
    el,
    field,
    setBusy(busy) {
      button.disabled = busy;
      form.classList.toggle('is-busy', busy);
      form.setAttribute('aria-busy', String(busy));
    },
    setError: (m) => field.setError(m),
    setValue: (v) => field.setValue(v),
    focus: () => field.focus(),
  };
}
