import { h } from '../utils/dom.js';
import { icon } from '../utils/icons.js';

/** Pesan status; role="alert" untuk galat agar dibacakan pembaca layar. */
export function Notice(kind, text) {
  return h('div', { class: `notice notice-${kind}`, role: kind === 'error' ? 'alert' : 'status' }, icon(kind === 'error' ? 'alert' : kind === 'success' ? 'check' : 'info', 18), h('span', {}, text));
}
