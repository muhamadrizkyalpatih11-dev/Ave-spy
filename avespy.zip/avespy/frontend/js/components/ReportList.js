import { h } from '../utils/dom.js';
import { CATEGORY_LABEL, formatDate } from '../utils/format.js';

export function ReportList(reports) {
  if (!reports.length) return h('p', { class: 'muted' }, 'Belum ada laporan yang disetujui untuk nomor ini.');
  return h('ul', { class: 'report-list' },
    reports.map((r) =>
      h('li', { class: 'report-item' },
        h('div', { class: 'report-head' },
          h('span', { class: 'chip' }, CATEGORY_LABEL[r.category] || r.category),
          r.tag ? h('span', { class: 'chip chip-tag' }, r.tag) : null,
          h('time', { datetime: r.createdAt, class: 'muted' }, formatDate(r.createdAt))),
        r.description ? h('p', { class: 'report-text' }, r.description) : null)));
}
