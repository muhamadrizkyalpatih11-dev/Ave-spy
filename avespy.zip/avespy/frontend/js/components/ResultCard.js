import { h } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { RiskBadge } from './RiskBadge.js';
import { ReportList } from './ReportList.js';
import { CATEGORY_LABEL, CONFIDENCE_LABEL, NA, formatDate, formatRelative } from '../utils/format.js';

const na = () => h('span', { class: 'na' }, NA);

function row(iconName, label, value, note) {
  return h('div', { class: 'info-row' },
    h('dt', {}, icon(iconName, 18), label),
    h('dd', {}, value ?? na(), note ? h('small', { class: 'muted block' }, note) : null));
}

function meter(score) {
  const track = h('div', { class: 'meter-track', role: 'img', 'aria-label': `Skor risiko ${score} dari 100` }, h('span', { class: 'meter-marker' }));
  track.style.setProperty('--pos', `${score}%`);
  return h('div', { class: 'meter' }, track,
    h('div', { class: 'meter-scale', 'aria-hidden': 'true' }, h('span', {}, 'Rendah'), h('span', {}, 'Waspada'), h('span', {}, 'Spam')));
}

export function ResultCard(data, { onReport, onShowMore }) {
  let revealed = false;
  const numberEl = h('h2', { class: 'result-number', id: 'result-title' }, data.number.masked);
  const reveal = h('button', { class: 'btn-ghost', type: 'button', 'aria-pressed': 'false' }, icon('eye', 18), 'Tampilkan nomor lengkap');
  reveal.addEventListener('click', () => {
    revealed = !revealed;
    numberEl.textContent = revealed ? data.number.international : data.number.masked;
    reveal.setAttribute('aria-pressed', String(revealed));
    reveal.replaceChildren(icon(revealed ? 'eyeOff' : 'eye', 18), revealed ? 'Sembunyikan nomor' : 'Tampilkan nomor lengkap');
  });

  const risk = data.risk;
  const status = data.suppressed ? 'hidden' : risk.status;

  const header = h('section', { class: 'card result-head', 'aria-labelledby': 'result-title' },
    h('div', { class: 'result-head-top' },
      h('div', {}, h('p', { class: 'muted' }, 'Nomor'), numberEl, reveal),
      h('div', { class: 'result-status' }, h('p', { class: 'muted' }, 'Status'), RiskBadge(status))),
    data.suppressed
      ? h('p', { class: 'notice-inline' }, 'Informasi komunitas untuk nomor ini disembunyikan atas permintaan pemiliknya.')
      : risk.status === 'unknown'
        ? h('p', { class: 'notice-inline' }, h('strong', {}, NA), ' untuk risiko: belum ada laporan komunitas yang disetujui. Ini bukan jaminan bahwa nomor aman.')
        : meter(risk.score));

  const info = h('section', { class: 'card', 'aria-labelledby': 'info-title' },
    h('h3', { id: 'info-title' }, 'Informasi nomor'),
    h('dl', { class: 'info-list' },
      row('globe', 'Negara', data.country.name ? `${data.country.name} (+${data.country.callingCode})` : `+${data.country.callingCode}`),
      row('tower', 'Operator', data.carrier?.name, data.carrier?.note),
      row('phone', 'Tipe nomor', data.type?.label),
      row('check', 'Validitas', 'Format valid (E.164)')));

  const cards = [header, info];

  if (!data.suppressed) {
    const cats = Object.entries(risk.categories).sort((a, b) => b[1] - a[1]);
    const max = cats[0]?.[1] || 1;
    const community = h('section', { class: 'card', 'aria-labelledby': 'com-title' },
      h('h3', { id: 'com-title' }, 'Laporan komunitas'),
      h('dl', { class: 'info-list' },
        row('users', 'Jumlah laporan', risk.reportCount ? `${risk.reportCount} laporan dari ${risk.distinctReporters} pelapor` : '0 laporan disetujui'),
        row('clock', 'Laporan terakhir', risk.lastReportAt ? `${formatDate(risk.lastReportAt)} (${formatRelative(risk.lastReportAt)})` : null),
        row('shield', 'Tingkat kepercayaan data', risk.reportCount ? CONFIDENCE_LABEL[risk.confidence] : null,
          risk.reportCount ? 'Semakin banyak pelapor berbeda, semakin tinggi.' : null)),
      cats.length
        ? h('ul', { class: 'cat-bars', 'aria-label': 'Kategori laporan' },
          cats.map(([key, n]) => {
            const bar = h('span', { class: 'cat-fill' });
            bar.style.setProperty('--w', `${Math.round((n / max) * 100)}%`);
            return h('li', {}, h('span', { class: 'cat-name' }, CATEGORY_LABEL[key] || key), h('span', { class: 'cat-track', 'aria-hidden': 'true' }, bar), h('span', { class: 'cat-n' }, n));
          }))
        : null);
    cards.push(community);

    if (data.tags.length) {
      cards.push(h('section', { class: 'card', 'aria-labelledby': 'tag-title' },
        h('h3', { id: 'tag-title' }, 'Tag komunitas'),
        h('p', { class: 'chips' }, data.tags.map((t) => h('span', { class: 'chip chip-tag' }, icon('tag', 14), `${t.tag} (${t.count})`))),
        h('p', { class: 'muted small' }, 'Tag berasal dari kontribusi komunitas dan belum tentu menunjukkan identitas pemilik nomor.')));
    }

    if (data.recentReports.length) {
      cards.push(h('section', { class: 'card', 'aria-labelledby': 'recent-title' },
        h('h3', { id: 'recent-title' }, 'Laporan terbaru'),
        ReportList(data.recentReports),
        risk.reportCount > data.recentReports.length
          ? h('button', { class: 'btn-ghost', type: 'button', onClick: () => onShowMore(data.number.e164) }, 'Lihat semua laporan')
          : null));
    }
  }

  const sources = h('section', { class: 'card card-quiet', 'aria-labelledby': 'src-title' },
    h('h3', { id: 'src-title' }, 'Sumber data'),
    h('ul', { class: 'plain-list' }, data.sources.map((s) => h('li', {}, h('strong', {}, s.name), h('span', { class: 'muted block' }, s.covers)))),
    h('p', { class: 'muted small' }, `Diperiksa ${new Date(data.checkedAt).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })}.`));
  cards.push(sources);

  const actions = h('div', { class: 'result-actions' },
    h('button', { class: 'btn btn-secondary', type: 'button', onClick: () => onReport(data) }, icon('flag', 18), 'Laporkan nomor ini'),
    h('a', { class: 'btn-ghost', href: '#/privacy' }, 'Anda pemilik nomor ini? Minta penghapusan data'));

  return h('div', { class: 'result-grid' }, cards, actions);
}
