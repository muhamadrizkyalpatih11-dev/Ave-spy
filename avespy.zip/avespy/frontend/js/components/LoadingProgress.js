import { h } from '../utils/dom.js';

const STEPS = ['Memvalidasi format nomor', 'Memeriksa negara dan operator', 'Membaca laporan komunitas'];

/** Indikator progres saat pengecekan. Langkah maju berdasarkan waktu; selesai saat respons datang. */
export function LoadingProgress() {
  const items = STEPS.map((text) => h('li', {}, text));
  const bar = h('div', { class: 'progress-bar' });
  const el = h('div', { class: 'progress card', role: 'status', 'aria-live': 'polite', hidden: true },
    h('p', { class: 'progress-title' }, 'Memeriksa nomor'),
    h('div', { class: 'progress-track', 'aria-hidden': 'true' }, bar),
    h('ol', { class: 'progress-steps' }, items));

  let timer = null;
  function paint(active) {
    items.forEach((li, i) => {
      li.classList.toggle('is-done', i < active);
      li.classList.toggle('is-active', i === active);
    });
    bar.style.setProperty('--p', `${Math.min(95, ((active + 0.5) / STEPS.length) * 100)}%`);
  }

  return {
    el,
    start() {
      let step = 0;
      el.hidden = false;
      paint(step);
      clearInterval(timer);
      timer = setInterval(() => {
        step = Math.min(step + 1, STEPS.length - 1);
        paint(step);
      }, 650);
    },
    stop() {
      clearInterval(timer);
      el.hidden = true;
    },
  };
}
