import { h } from '../utils/dom.js';

export function Footer() {
  return h('footer', { class: 'site-footer' },
    h('div', { class: 'container footer-inner' },
      h('p', {}, 'Avespy membantu Anda menilai risiko sebuah nomor telepon dari data yang sah dan laporan komunitas. Hasil bukan identitas resmi pemilik nomor.'),
      h('p', { class: 'footer-links' },
        h('a', { href: '#/privacy' }, 'Privacy Center'),
        h('a', { href: '#/terms' }, 'Ketentuan Layanan'),
        h('a', { href: '#/tentang' }, 'Sumber data'))));
}
