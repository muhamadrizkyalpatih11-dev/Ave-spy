import { h } from '../utils/dom.js';
import { CaptchaWidget } from './CaptchaWidget.js';
import { Notice } from './Notice.js';

/**
 * Menjalankan aksi; jika server meminta CAPTCHA (428), tampilkan widget di `host`
 * lalu ulangi aksi dengan jawaban pengguna.
 */
export async function runGated(action, host) {
  try {
    return await action(undefined);
  } catch (err) {
    if (err.code !== 'CAPTCHA_REQUIRED') throw err;
    return promptAndRun(action, host, err.message);
  }
}

function promptAndRun(action, host, firstMessage) {
  return new Promise((resolve, reject) => {
    const widget = CaptchaWidget();
    const message = h('div', {}, Notice('info', firstMessage));
    const button = h('button', { class: 'btn', type: 'button' }, 'Verifikasi dan lanjutkan');
    const panel = h('div', { class: 'gate card' }, message, widget.el, h('div', { class: 'row-end' }, button));
    host.replaceChildren(panel);

    button.addEventListener('click', async () => {
      const value = widget.getValue();
      if (!value) {
        message.replaceChildren(Notice('error', 'Lengkapi verifikasi keamanan terlebih dahulu.'));
        return;
      }
      button.disabled = true;
      try {
        const result = await action(value);
        host.replaceChildren();
        resolve(result);
      } catch (err) {
        button.disabled = false;
        if (err.code === 'CAPTCHA_REQUIRED') {
          message.replaceChildren(Notice('error', err.message));
          widget.refresh();
        } else {
          host.replaceChildren();
          reject(err);
        }
      }
    });
  });
}
