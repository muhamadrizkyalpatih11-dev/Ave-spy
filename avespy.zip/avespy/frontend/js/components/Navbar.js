import { h } from '../utils/dom.js';
import { icon } from '../utils/icons.js';
import { currentTheme, toggleTheme } from '../utils/theme.js';

const LINKS = [
  ['/', 'Home'],
  ['/cek', 'Cek Nomor'],
  ['/laporan', 'Laporan'],
  ['/privacy', 'Privacy'],
  ['/tentang', 'Tentang'],
];

export function Navbar() {
  const nav = h('nav', { id: 'site-nav', class: 'nav-links', 'aria-label': 'Navigasi utama' },
    LINKS.map(([path, label]) => h('a', { href: `#${path}`, dataset: undefined, 'data-path': path }, label)));

  const menuBtn = h('button', { class: 'icon-btn nav-toggle', type: 'button', 'aria-expanded': 'false', 'aria-controls': 'site-nav', 'aria-label': 'Buka menu' }, icon('menu'));
  menuBtn.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    menuBtn.setAttribute('aria-expanded', String(open));
  });
  nav.addEventListener('click', (e) => {
    if (e.target.tagName === 'A') {
      nav.classList.remove('is-open');
      menuBtn.setAttribute('aria-expanded', 'false');
    }
  });

  const themeBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Ganti mode tampilan' });
  const paintTheme = () => {
    themeBtn.replaceChildren(icon(currentTheme() === 'dark' ? 'sun' : 'moon'));
    themeBtn.setAttribute('title', currentTheme() === 'dark' ? 'Mode terang' : 'Mode gelap');
  };
  themeBtn.addEventListener('click', () => {
    toggleTheme();
    paintTheme();
  });
  paintTheme();

  const el = h('header', { class: 'site-header' },
    h('div', { class: 'container header-inner' },
      h('a', { class: 'brand', href: '#/', 'aria-label': 'Avespy, ke beranda' }, icon('shield', 26), h('span', {}, 'AVESPY')),
      nav,
      h('div', { class: 'header-actions' }, themeBtn, menuBtn)));

  return {
    el,
    setActive(path) {
      nav.querySelectorAll('a').forEach((a) => {
        if (a.dataset.path === path) a.setAttribute('aria-current', 'page');
        else a.removeAttribute('aria-current');
      });
    },
  };
}
