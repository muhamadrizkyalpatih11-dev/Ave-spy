// Dijalankan sinkron di <head> agar tema tidak berkedip saat halaman dimuat.
(function () {
  try {
    var saved = localStorage.getItem('avespy-theme');
    var dark = saved ? saved === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  } catch (e) {
    document.documentElement.dataset.theme = 'light';
  }
})();
