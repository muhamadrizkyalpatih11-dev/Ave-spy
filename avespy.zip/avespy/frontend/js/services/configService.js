import { api } from '../api/endpoints.js';

const FALLBACK = {
  regions: [{ code: 'ID', callingCode: '62', name: 'Indonesia' }],
  captcha: { provider: 'builtin', siteKey: null },
};
let cached = FALLBACK;

export async function loadConfig() {
  try {
    cached = (await api.config()).data;
  } catch {
    cached = FALLBACK;
  }
  return cached;
}

export const getConfig = () => cached;
