import { api } from '../api/endpoints.js';
import { AppError } from '../utils/errors.js';
import { validateNumberInput } from '../utils/validators.js';

export async function submitReport({ region, number, category, tag, description, consent, captcha }) {
  const problem = validateNumberInput(number);
  if (problem) throw new AppError('VALIDATION_ERROR', problem);
  if (!category) throw new AppError('VALIDATION_ERROR', 'Pilih kategori laporan.');
  if (!consent) throw new AppError('VALIDATION_ERROR', 'Anda harus menyetujui ketentuan pelaporan.');
  if (!captcha) throw new AppError('VALIDATION_ERROR', 'Selesaikan verifikasi keamanan.');
  const payload = { region, number: number.trim(), category, consent: true, captcha };
  if (tag) payload.tag = tag;
  if (description?.trim()) payload.description = description.trim();
  return (await api.createReport(payload)).data;
}

export async function deleteMyReport({ id, token }) {
  if (!/^\d+$/.test(String(id).trim())) throw new AppError('VALIDATION_ERROR', 'ID laporan tidak valid.');
  if (!token?.trim()) throw new AppError('VALIDATION_ERROR', 'Masukkan token penghapusan.');
  return (await api.deleteReport(String(id).trim(), token.trim())).data;
}
