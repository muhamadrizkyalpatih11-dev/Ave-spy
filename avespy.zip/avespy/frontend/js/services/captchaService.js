import { api } from '../api/endpoints.js';
import { getConfig } from './configService.js';

export const captchaProvider = () => getConfig().captcha;
export const fetchChallenge = async () => (await api.captcha()).data;
