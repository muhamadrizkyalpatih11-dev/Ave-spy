import { api } from '../api/endpoints.js';
import { AppError } from '../utils/errors.js';
import { isEmail, validateNumberInput } from '../utils/validators.js';

export async function requestDataRemoval({ region, number, email, reason, consent, captcha }) {
  const problem = validateNumberInput(number);
  if (problem) throw new AppError('VALIDATION_ERROR', problem);
  if (!isEmail(email)) throw new AppError('VALIDATION_ERROR', 'Email tidak valid.');
  if (!consent) throw new AppError('VALIDATION_ERROR', 'Anda harus menyatakan bahwa Anda pemilik nomor atau perwakilannya.');
  if (!captcha) throw new AppError('VALIDATION_ERROR', 'Selesaikan verifikasi keamanan.');
  const payload = { region, number: number.trim(), email: email.trim(), consent: true, captcha };
  if (reason?.trim()) payload.reason = reason.trim();
  return (await api.requestRemoval(payload)).data;
}
