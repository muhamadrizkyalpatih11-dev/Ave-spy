import { api } from '../api/endpoints.js';
import { AppError } from '../utils/errors.js';
import { validateNumberInput } from '../utils/validators.js';

export async function checkNumber({ region, number, captcha }) {
  const problem = validateNumberInput(number);
  if (problem) throw new AppError('VALIDATION_ERROR', problem);
  const payload = { region, number: number.trim() };
  if (captcha) payload.captcha = captcha;
  return (await api.lookup(payload)).data;
}

export async function listCommunityReports({ e164, page = 1, captcha }) {
  return (await api.reportsFor(e164, page, captcha)).data;
}
