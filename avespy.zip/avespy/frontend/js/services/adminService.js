import { adminApi } from '../api/endpoints.js';

export const adminService = {
  login: async (email, password) => (await adminApi.login(email, password)).data.admin,
  logout: () => adminApi.logout(),
  currentAdmin: async () => (await adminApi.me()).data.admin,
  stats: async () => (await adminApi.stats()).data,
  reports: async (params) => (await adminApi.reports(params)).data,
  moderateReport: (id, action, note) => adminApi.moderateReport(id, action, note),
  deleteReport: (id) => adminApi.deleteReport(id),
  removals: async (params) => (await adminApi.removals(params)).data,
  handleRemoval: (id, action, note) => adminApi.handleRemoval(id, action, note),
  abuseEvents: async (params) => (await adminApi.abuseEvents(params)).data,
  auditLogs: async (params) => (await adminApi.auditLogs(params)).data,
};
