import 'dotenv/config';
import crypto from 'node:crypto';

const env = process.env;
const isProd = env.NODE_ENV === 'production';

function secret(name, devFallback) {
  const value = env[name];
  if (value && value.length >= 32) return value;
  if (isProd) {
    throw new Error(`${name} wajib diisi dengan minimal 32 karakter acak pada mode production.`);
  }
  console.warn(`[config] ${name} belum diset. Memakai nilai sementara (hanya untuk development).`);
  return devFallback;
}

function parseTrustProxy(value) {
  if (!value) return false;
  const n = Number(value);
  return Number.isNaN(n) ? value : n;
}

export const config = {
  env: env.NODE_ENV || 'development',
  isProd,
  port: Number(env.PORT) || 3000,
  trustProxy: parseTrustProxy(env.TRUST_PROXY),
  databaseUrl: env.DATABASE_URL || 'postgres://avespy:avespy@localhost:5432/avespy',
  dbSsl: env.DB_SSL === 'true',
  jwtSecret: secret('JWT_SECRET', crypto.randomBytes(32).toString('hex')),
  hashPepper: secret('HASH_PEPPER', 'dev-only-pepper-jangan-dipakai-di-production'),
  captcha: {
    provider: env.CAPTCHA_PROVIDER === 'turnstile' ? 'turnstile' : 'builtin',
    siteKey: env.TURNSTILE_SITE_KEY || '',
    secretKey: env.TURNSTILE_SECRET_KEY || '',
  },
};

if (config.captcha.provider === 'turnstile' && (!config.captcha.siteKey || !config.captcha.secretKey)) {
  throw new Error('CAPTCHA_PROVIDER=turnstile membutuhkan TURNSTILE_SITE_KEY dan TURNSTILE_SECRET_KEY.');
}
