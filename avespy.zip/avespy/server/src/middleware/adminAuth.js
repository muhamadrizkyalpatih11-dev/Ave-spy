import { config } from '../config.js';
import { AppError } from '../utils/errors.js';
import { safeEqual } from '../utils/crypto.js';
import { findAdmin, verifyAdminToken, ADMIN_TOKEN_TTL_SECONDS } from '../services/adminAuthService.js';

export const ADMIN_COOKIE = 'avespy_admin';
export const CSRF_COOKIE = 'avespy_csrf';

export function setAdminCookies(res, token, csrf) {
  const base = { sameSite: 'strict', secure: config.isProd, path: '/', maxAge: ADMIN_TOKEN_TTL_SECONDS * 1000 };
  res.cookie(ADMIN_COOKIE, token, { ...base, httpOnly: true });
  res.cookie(CSRF_COOKIE, csrf, { ...base, httpOnly: false });
}

export function clearAdminCookies(res) {
  res.clearCookie(ADMIN_COOKIE, { path: '/' });
  res.clearCookie(CSRF_COOKIE, { path: '/' });
}

function checkCsrf(req) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return;
  const origin = req.get('origin');
  if (origin) {
    let host;
    try { host = new URL(origin).host; } catch { host = null; }
    if (host !== req.get('host')) throw new AppError(403, 'BAD_ORIGIN', 'Permintaan ditolak.');
  }
  const cookie = req.cookies?.[CSRF_COOKIE];
  const header = req.get('x-csrf-token');
  if (!cookie || !header || !safeEqual(cookie, header)) {
    throw new AppError(403, 'CSRF_FAILED', 'Permintaan ditolak. Muat ulang halaman.');
  }
}

export async function requireAdmin(req, _res, next) {
  try {
    const token = req.cookies?.[ADMIN_COOKIE];
    if (!token) throw new AppError(401, 'UNAUTHENTICATED', 'Silakan masuk terlebih dahulu.');
    let payload;
    try {
      payload = verifyAdminToken(token);
    } catch {
      throw new AppError(401, 'SESSION_EXPIRED', 'Sesi berakhir. Silakan masuk kembali.');
    }
    checkCsrf(req);
    const admin = await findAdmin(payload.sub); // peran diambil dari database, bukan dari token
    if (!admin) throw new AppError(401, 'UNAUTHENTICATED', 'Silakan masuk terlebih dahulu.');
    req.admin = admin;
    next();
  } catch (err) {
    next(err);
  }
}

export const requireRole = (...roles) => (req, _res, next) =>
  roles.includes(req.admin?.role) ? next() : next(new AppError(403, 'FORBIDDEN', 'Anda tidak memiliki izin untuk aksi ini.'));
