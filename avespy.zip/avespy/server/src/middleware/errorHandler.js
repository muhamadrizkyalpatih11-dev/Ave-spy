import { AppError, UNAVAILABLE_MESSAGE } from '../utils/errors.js';

export function notFoundApi(_req, res) {
  res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Endpoint tidak ditemukan.' } });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, _next) {
  if (err instanceof AppError) {
    return res.status(err.status).json({ error: { code: err.code, message: err.message } });
  }
  if (err?.type === 'entity.parse.failed' || err?.type === 'entity.too.large') {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Permintaan tidak valid.' } });
  }
  // Jangan mencatat body request (bisa memuat nomor telepon).
  console.error(`[error] ${req.method} ${req.path}:`, err?.message || err);
  return res.status(503).json({ error: { code: 'SERVICE_UNAVAILABLE', message: UNAVAILABLE_MESSAGE } });
}
