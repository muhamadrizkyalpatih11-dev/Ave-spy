import { hmac } from '../utils/crypto.js';

/** Menempelkan hash IP ke request. IP asli tidak pernah disimpan ke database. */
export function attachClient(req, _res, next) {
  req.ipHash = hmac(req.ip || 'unknown');
  next();
}
