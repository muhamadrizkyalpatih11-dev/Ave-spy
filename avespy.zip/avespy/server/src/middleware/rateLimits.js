import rateLimit from 'express-rate-limit';
import { slowDown } from 'express-slow-down';
import { logAbuse } from '../services/auditService.js';

function limiter(name, windowMs, limit, message) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => {
      logAbuse('rate_limit', req.ipHash, { limiter: name });
      res.status(429).json({ error: { code: 'RATE_LIMITED', message } });
    },
  });
}

const TOO_MANY = 'Terlalu banyak permintaan. Coba lagi beberapa saat lagi.';

export const globalLimiter = limiter('global', 60_000, 120, TOO_MANY);
export const sessionLimiter = limiter('session', 60_000, 10, TOO_MANY);
export const lookupLimiter = limiter('lookup', 60_000, 10, TOO_MANY);
export const reportLimiter = limiter('report', 60 * 60_000, 5, 'Batas pengiriman laporan tercapai. Coba lagi dalam satu jam.');
export const removalLimiter = limiter('removal', 24 * 60 * 60_000, 3, 'Batas permintaan harian tercapai. Coba lagi besok.');
export const adminLoginLimiter = limiter('admin_login', 15 * 60_000, 10, 'Terlalu banyak percobaan masuk. Coba lagi nanti.');

/** Request throttling: permintaan beruntun diperlambat secara bertahap sebelum ditolak. */
export const lookupSlowDown = slowDown({
  windowMs: 60_000,
  delayAfter: 5,
  delayMs: (used) => (used - 5) * 300,
  maxDelayMs: 3000,
});
