import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { AppError } from '../utils/errors.js';
import { randomToken } from '../utils/crypto.js';

const SESSION_TTL_SECONDS = 30 * 60;

export function issueSessionToken() {
  const token = jwt.sign({ sid: randomToken(12) }, config.jwtSecret, {
    audience: 'avespy-public',
    issuer: 'avespy',
    expiresIn: SESSION_TTL_SECONDS,
  });
  return { token, expiresIn: SESSION_TTL_SECONDS };
}

/** Autentikasi API publik: setiap permintaan wajib membawa token sesi anonim (Bearer). */
export function requireSession(req, _res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme !== 'Bearer' || !token) {
    return next(new AppError(401, 'UNAUTHENTICATED', 'Sesi tidak valid. Muat ulang halaman.'));
  }
  try {
    const payload = jwt.verify(token, config.jwtSecret, { audience: 'avespy-public', issuer: 'avespy' });
    req.session = { sid: payload.sid };
    return next();
  } catch {
    return next(new AppError(401, 'SESSION_EXPIRED', 'Sesi berakhir. Muat ulang halaman.'));
  }
}
