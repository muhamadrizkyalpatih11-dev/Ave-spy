import { Router } from 'express';
import { config } from '../config.js';
import { asyncHandler, AppError } from '../utils/errors.js';
import { parse } from '../utils/validate.js';
import { requireSession, issueSessionToken } from '../middleware/session.js';
import { lookupLimiter, lookupSlowDown, reportLimiter, removalLimiter, sessionLimiter } from '../middleware/rateLimits.js';
import { assertNotBlocked, enforceLookupPolicy } from '../services/abuseDetector.js';
import { createBuiltinChallenge, verifyCaptcha } from '../services/captchaService.js';
import { logAbuse } from '../services/auditService.js';
import { parseNumber, regionList } from '../services/phoneService.js';
import { isSuppressed, lookup } from '../services/lookupService.js';
import { createReport, deleteOwnReport, listApprovedReports, sanitizeDescription } from '../services/reportService.js';
import { createRemovalRequest } from '../services/removalService.js';
import { hmac } from '../utils/crypto.js';
import {
  deleteOwnSchema, idSchema, lookupSchema, removalSchema, reportListQuery, reportSchema,
} from '../validation/schemas.js';

const router = Router();

// --- Bootstrap (tanpa data sensitif) ---
router.get('/health', (_req, res) => res.json({ ok: true }));

router.get('/config', (_req, res) => {
  res.json({
    data: {
      regions: regionList(),
      captcha: { provider: config.captcha.provider, siteKey: config.captcha.provider === 'turnstile' ? config.captcha.siteKey : null },
    },
  });
});

router.post('/session', sessionLimiter, (_req, res) => res.json({ data: issueSessionToken() }));

router.get('/captcha', sessionLimiter, (_req, res) => {
  if (config.captcha.provider !== 'builtin') throw new AppError(404, 'NOT_FOUND', 'Tidak tersedia.');
  res.json({ data: createBuiltinChallenge() });
});

// Semua endpoint di bawah membutuhkan token sesi (API authentication).
router.use(requireSession);

async function requireCaptcha(req, captcha) {
  if (!(await verifyCaptcha(captcha, req.ip))) {
    logAbuse('captcha_failed', req.ipHash, { path: req.path });
    throw new AppError(400, 'CAPTCHA_INVALID', 'Verifikasi keamanan gagal. Coba lagi.');
  }
}

// --- POST /api/lookup ---
router.post('/lookup', lookupLimiter, lookupSlowDown, asyncHandler(async (req, res) => {
  const input = parse(lookupSchema, req.body);
  const parsed = parseNumber(input.number, input.region);
  await enforceLookupPolicy(req, parsed.number, input.captcha);
  res.json({ data: await lookup(parsed) });
}));

// --- GET /api/reports/:number (nomor E.164, satu per permintaan) ---
router.get('/reports/:number', lookupLimiter, lookupSlowDown, asyncHandler(async (req, res) => {
  const { page } = parse(reportListQuery, req.query);
  const raw = req.params.number;
  if (!/^\+\d{6,15}$/.test(raw)) throw new AppError(422, 'INVALID_NUMBER', 'Nomor telepon tidak valid.');
  const parsed = parseNumber(raw);
  const captcha = req.get('x-captcha-token')
    ? { token: req.get('x-captcha-token'), answer: req.get('x-captcha-answer') || undefined }
    : undefined;
  await enforceLookupPolicy(req, parsed.number, captcha);
  if (await isSuppressed(parsed.number)) {
    return res.json({ data: { total: 0, page, pageSize: 10, reports: [], suppressed: true } });
  }
  res.json({ data: await listApprovedReports(parsed.number, page) });
}));

// --- POST /api/reports ---
router.post('/reports', reportLimiter, asyncHandler(async (req, res) => {
  assertNotBlocked(req.ipHash);
  const input = parse(reportSchema, req.body);
  await requireCaptcha(req, input.captcha);
  const parsed = parseNumber(input.number, input.region);
  if (await isSuppressed(parsed.number)) {
    throw new AppError(403, 'NUMBER_SUPPRESSED', 'Nomor ini tidak menerima laporan baru atas permintaan pemiliknya.');
  }
  const description = sanitizeDescription(input.description);
  const { id, deleteToken } = await createReport({
    e164: parsed.number,
    country: parsed.country,
    category: input.category,
    tag: input.tag,
    description,
    reporterHash: hmac(`reporter:${req.ip}`),
    ipHash: req.ipHash,
  });
  res.status(201).json({
    data: {
      id,
      status: 'pending',
      deleteToken,
      message: 'Laporan diterima dan akan ditinjau moderator sebelum dihitung.',
    },
  });
}));

// --- DELETE /api/reports/:id (pelapor menghapus laporannya sendiri) ---
router.delete('/reports/:id', reportLimiter, asyncHandler(async (req, res) => {
  const id = parse(idSchema, req.params.id);
  const { token } = parse(deleteOwnSchema, req.body);
  await deleteOwnReport(id, token, req.ipHash);
  res.json({ data: { deleted: true } });
}));

// --- POST /api/removal-request ---
router.post('/removal-request', removalLimiter, asyncHandler(async (req, res) => {
  assertNotBlocked(req.ipHash);
  const input = parse(removalSchema, req.body);
  await requireCaptcha(req, input.captcha);
  const parsed = parseNumber(input.number, input.region);
  const { id, duplicate } = await createRemovalRequest({
    e164: parsed.number,
    email: input.email,
    reason: input.reason,
    ipHash: req.ipHash,
  });
  res.status(201).json({
    data: {
      reference: `RM-${id}`,
      duplicate,
      message: 'Permintaan diterima. Moderator akan memverifikasi kepemilikan nomor sebelum memprosesnya.',
    },
  });
}));

export default router;
