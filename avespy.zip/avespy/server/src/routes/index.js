import { Router } from 'express';
import publicRoutes from './public.js';
import adminRoutes from './admin.js';
import { globalLimiter } from '../middleware/rateLimits.js';
import { attachClient } from '../middleware/client.js';
import { notFoundApi } from '../middleware/errorHandler.js';

const api = Router();
api.use(attachClient);
api.use(globalLimiter);
api.use((_req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});
api.use('/admin', adminRoutes);
api.use('/', publicRoutes);
api.use(notFoundApi);

export default api;
