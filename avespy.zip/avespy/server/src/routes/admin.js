import { Router } from 'express';
import crypto from 'node:crypto';
import { asyncHandler } from '../utils/errors.js';
import { parse } from '../utils/validate.js';
import { adminLoginLimiter } from '../middleware/rateLimits.js';
import { ADMIN_COOKIE, clearAdminCookies, requireAdmin, requireRole, setAdminCookies } from '../middleware/adminAuth.js';
import { login } from '../services/adminAuthService.js';
import { audit } from '../services/auditService.js';
import {
  deleteReportAsAdmin, listReportsForAdmin, moderateReport,
} from '../services/reportService.js';
import { handleRemovalRequest, listRemovalRequests } from '../services/removalService.js';
import { getDashboardStats, listAbuseEvents, listAuditLogs } from '../services/statsService.js';
import {
  adminLoginSchema, adminModerateSchema, adminRemovalAction, adminRemovalQuery, adminReportsQuery,
  idSchema, pageQuery,
} from '../validation/schemas.js';

const router = Router();
const PAGE_SIZE = 20;

router.use((_req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// --- Autentikasi ---
router.post('/auth/login', adminLoginLimiter, asyncHandler(async (req, res) => {
  const { email, password } = parse(adminLoginSchema, req.body);
  const { token, admin } = await login(email, password, req.ipHash);
  setAdminCookies(res, token, crypto.randomBytes(24).toString('base64url'));
  res.json({ data: { admin } });
}));

router.post('/auth/logout', requireAdmin, asyncHandler(async (req, res) => {
  await audit({ actorType: 'admin', actorId: req.admin.id, action: 'admin.logout', ipHash: req.ipHash });
  clearAdminCookies(res);
  res.json({ data: { ok: true } });
}));

// Semua route berikut wajib login admin (cookie httpOnly + CSRF untuk metode non-GET).
router.use(requireAdmin);

router.get('/auth/me', (req, res) => res.json({ data: { admin: req.admin } }));

router.get('/stats', asyncHandler(async (_req, res) => res.json({ data: await getDashboardStats() })));

// --- Laporan komunitas ---
router.get('/reports', asyncHandler(async (req, res) => {
  const q = parse(adminReportsQuery, req.query);
  res.json({ data: await listReportsForAdmin({ ...q, pageSize: PAGE_SIZE }) });
}));

router.patch('/reports/:id', asyncHandler(async (req, res) => {
  const id = parse(idSchema, req.params.id);
  const { action, note } = parse(adminModerateSchema, req.body);
  await moderateReport(id, action, note, req.admin, req.ipHash);
  res.json({ data: { ok: true } });
}));

router.delete('/reports/:id', asyncHandler(async (req, res) => {
  await deleteReportAsAdmin(parse(idSchema, req.params.id), req.admin, req.ipHash);
  res.json({ data: { ok: true } });
}));

// --- Permintaan penghapusan data ---
router.get('/removal-requests', asyncHandler(async (req, res) => {
  const q = parse(adminRemovalQuery, req.query);
  res.json({ data: await listRemovalRequests({ ...q, pageSize: PAGE_SIZE }) });
}));

router.patch('/removal-requests/:id', asyncHandler(async (req, res) => {
  const id = parse(idSchema, req.params.id);
  const { action, note } = parse(adminRemovalAction, req.body);
  await handleRemovalRequest(id, action, note, req.admin, req.ipHash);
  res.json({ data: { ok: true } });
}));

// --- Abuse & audit ---
router.get('/abuse-events', asyncHandler(async (req, res) => {
  const { page } = parse(pageQuery, req.query);
  res.json({ data: await listAbuseEvents({ page, pageSize: PAGE_SIZE }) });
}));

router.get('/audit-logs', requireRole('admin'), asyncHandler(async (req, res) => {
  const { page } = parse(pageQuery, req.query);
  res.json({ data: await listAuditLogs({ page, pageSize: PAGE_SIZE }) });
}));

export default router;
export { ADMIN_COOKIE };
