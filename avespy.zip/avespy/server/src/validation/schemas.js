import { z } from 'zod';
import { REGIONS } from '../services/phoneService.js';

export const CATEGORIES = ['scam', 'spam', 'telemarketing', 'pinjol', 'phishing', 'robocall', 'other'];
export const TAGS = ['sales', 'spam', 'kurir', 'customer service', 'penagihan', 'survei'];

const EMPTY = 'Masukkan nomor telepon terlebih dahulu.';
const INVALID = 'Nomor telepon tidak valid.';

const number = z
  .string({ required_error: EMPTY, invalid_type_error: INVALID })
  .trim()
  .min(1, EMPTY)
  .max(24, INVALID)
  .regex(/^\+?[\d\s().-]+$/, INVALID); // satu nomor saja: tanpa koma, baris baru, atau huruf

const region = z
  .enum(Object.keys(REGIONS), { errorMap: () => ({ message: 'Kode negara tidak didukung.' }) })
  .default('ID');

const captcha = z.object({ token: z.string().max(2000), answer: z.string().max(20).optional() }).strict();
const consent = (msg) => z.literal(true, { errorMap: () => ({ message: msg }) });
const idParam = z.coerce.number({ invalid_type_error: 'ID tidak valid.' }).int('ID tidak valid.').positive('ID tidak valid.');
const page = z.coerce.number().int().min(1).max(10_000).default(1);
const note = z.string().trim().max(200).optional();

export const lookupSchema = z.object({ region, number, captcha: captcha.optional() }).strict();

export const reportSchema = z
  .object({
    region,
    number,
    category: z.enum(CATEGORIES, { errorMap: () => ({ message: 'Pilih kategori laporan.' }) }),
    tag: z.enum(TAGS).optional(),
    description: z.string().max(280, 'Deskripsi maksimal 280 karakter.').optional(),
    consent: consent('Anda harus menyetujui ketentuan pelaporan.'),
    captcha,
  })
  .strict();

export const removalSchema = z
  .object({
    region,
    number,
    email: z.string().trim().email('Email tidak valid.').max(200),
    reason: z.string().trim().max(500, 'Alasan maksimal 500 karakter.').optional(),
    consent: consent('Anda harus menyatakan bahwa Anda pemilik nomor atau perwakilannya.'),
    captcha,
  })
  .strict();

export const deleteOwnSchema = z
  .object({ token: z.string().min(10, 'Token penghapusan tidak valid.').max(100) })
  .strict();

export const reportListQuery = z.object({ page });
export const idSchema = idParam;

export const adminLoginSchema = z
  .object({ email: z.string().trim().email('Email tidak valid.').max(200), password: z.string().min(1).max(200) })
  .strict();

export const adminReportsQuery = z.object({
  status: z.enum(['pending', 'approved', 'rejected']).optional(),
  category: z.enum(CATEGORIES).optional(),
  page,
});
export const adminModerateSchema = z.object({ action: z.enum(['approve', 'reject']), note }).strict();
export const adminRemovalQuery = z.object({ status: z.enum(['pending', 'approved', 'rejected']).optional(), page });
export const adminRemovalAction = z.object({ action: z.enum(['approve', 'reject']), note }).strict();
export const pageQuery = z.object({ page });
