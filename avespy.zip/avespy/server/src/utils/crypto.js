import crypto from 'node:crypto';
import { config } from '../config.js';

/** Hash berkunci (HMAC) untuk IP, nomor telepon pada daftar penekanan, dan identitas pelapor. */
export const hmac = (value) =>
  crypto.createHmac('sha256', config.hashPepper).update(String(value)).digest('hex');

export const sha256 = (value) => crypto.createHash('sha256').update(String(value)).digest('hex');

export const randomToken = (bytes = 24) => crypto.randomBytes(bytes).toString('base64url');

export function safeEqual(a, b) {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
}
