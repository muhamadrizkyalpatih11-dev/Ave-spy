import { AppError } from './errors.js';

/** Validasi input dengan skema zod; melempar 400 dengan pesan pertama yang ramah pengguna. */
export function parse(schema, data) {
  const result = schema.safeParse(data ?? {});
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new AppError(400, 'VALIDATION_ERROR', issue?.message || 'Permintaan tidak valid.');
  }
  return result.data;
}
