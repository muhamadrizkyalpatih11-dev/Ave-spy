import { query } from '../db/pool.js';

/**
 * Operator berdasarkan prefix numbering plan. Karena portabilitas nomor (MNP),
 * hasil ini hanya indikasi awal, sehingga tingkat kepercayaannya selalu "rendah".
 * Bila tidak ada prefix yang cocok, mengembalikan null (UI menampilkan DATA TIDAK TERSEDIA).
 */
export async function lookupCarrier(countryCode, nationalNumber) {
  if (!countryCode) return null;
  const { rows } = await query(
    `SELECT carrier FROM carrier_prefixes
      WHERE country = $1 AND $2 LIKE prefix || '%'
      ORDER BY length(prefix) DESC LIMIT 1`,
    [countryCode, String(nationalNumber)],
  );
  if (!rows.length) return null;
  return {
    name: rows[0].carrier,
    confidence: 'low',
    note: 'Berdasarkan alokasi prefix. Nomor mungkin sudah berpindah operator.',
  };
}
