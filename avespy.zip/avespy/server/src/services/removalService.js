import { query, withTransaction } from '../db/pool.js';
import { AppError } from '../utils/errors.js';
import { hmac } from '../utils/crypto.js';
import { audit } from './auditService.js';

export async function createRemovalRequest({ e164, email, reason, ipHash }) {
  const numberHash = hmac(e164);
  const pending = await query(
    `SELECT id FROM removal_requests WHERE number_hash = $1 AND status = 'pending' LIMIT 1`,
    [numberHash],
  );
  if (pending.rowCount) {
    return { id: Number(pending.rows[0].id), duplicate: true };
  }
  const { rows } = await query(
    `INSERT INTO removal_requests (number_e164, number_hash, contact_email, reason)
     VALUES ($1,$2,$3,$4) RETURNING id`,
    [e164, numberHash, email, reason || null],
  );
  await audit({ actorType: 'public', action: 'removal.create', target: `removal:${rows[0].id}`, ipHash });
  return { id: Number(rows[0].id), duplicate: false };
}

export async function listRemovalRequests({ status, page, pageSize }) {
  const params = [];
  let clause = '';
  if (status) { params.push(status); clause = `WHERE status = $1`; }
  params.push(pageSize, (page - 1) * pageSize);
  const { rows } = await query(
    `SELECT id, number_e164, contact_email, reason, status, handled_at, note, created_at
       FROM removal_requests ${clause}
      ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params,
  );
  const total = await query(`SELECT count(*)::int AS n FROM removal_requests ${clause}`, params.slice(0, -2));
  return { total: total.rows[0].n, page, pageSize, items: rows };
}

/**
 * Menyetujui permintaan: nomor masuk daftar penekanan (hanya hash), seluruh laporan untuk nomor
 * tersebut dihapus, dan nomor mentah dikosongkan dari permintaan.
 * Verifikasi kepemilikan nomor dilakukan moderator SEBELUM menyetujui (lihat README).
 */
export async function handleRemovalRequest(id, action, note, admin, ipHash) {
  await withTransaction(async (client) => {
    const found = await client.query('SELECT number_e164, number_hash, status FROM removal_requests WHERE id = $1 FOR UPDATE', [id]);
    if (!found.rowCount) throw new AppError(404, 'NOT_FOUND', 'Permintaan tidak ditemukan.');
    const req = found.rows[0];
    if (req.status !== 'pending') throw new AppError(409, 'ALREADY_HANDLED', 'Permintaan ini sudah diproses.');

    if (action === 'approve') {
      await client.query('INSERT INTO suppressed_numbers (number_hash) VALUES ($1) ON CONFLICT DO NOTHING', [req.number_hash]);
      if (req.number_e164) await client.query('DELETE FROM reports WHERE number_e164 = $1', [req.number_e164]);
    }
    await client.query(
      `UPDATE removal_requests
          SET status = $2, handled_by = $3, handled_at = now(), note = $4,
              number_e164 = NULL
        WHERE id = $1`,
      [id, action === 'approve' ? 'approved' : 'rejected', admin.id, note || null],
    );
  });
  await audit({ actorType: 'admin', actorId: admin.id, action: `removal.${action}`, target: `removal:${id}`, meta: { note: note || null }, ipHash });
}
