import { query } from '../db/pool.js';

/** Penghapusan otomatis sesuai Privacy Center. Dijalankan saat start dan setiap 24 jam. */
export async function runRetention() {
  const jobs = [
    [`DELETE FROM reports WHERE status = 'approved' AND created_at < now() - interval '24 months'`, 'laporan disetujui > 24 bulan'],
    [`DELETE FROM reports WHERE status = 'pending' AND created_at < now() - interval '90 days'`, 'laporan menunggu > 90 hari'],
    [`DELETE FROM reports WHERE status = 'rejected' AND moderated_at < now() - interval '30 days'`, 'laporan ditolak > 30 hari'],
    [`UPDATE removal_requests SET contact_email = NULL WHERE contact_email IS NOT NULL AND status <> 'pending' AND handled_at < now() - interval '30 days'`, 'email permintaan penghapusan'],
    [`DELETE FROM abuse_events WHERE created_at < now() - interval '30 days'`, 'event abuse > 30 hari'],
    [`DELETE FROM audit_logs WHERE created_at < now() - interval '12 months'`, 'audit log > 12 bulan'],
    [`DELETE FROM lookup_stats WHERE day < CURRENT_DATE - 730`, 'statistik > 24 bulan'],
  ];
  for (const [sql, label] of jobs) {
    try {
      const res = await query(sql);
      if (res.rowCount) console.log(`[retention] ${label}: ${res.rowCount} baris`);
    } catch (err) {
      console.error(`[retention] gagal (${label}):`, err.message);
    }
  }
}

export function startRetention() {
  runRetention();
  setInterval(runRetention, 24 * 60 * 60_000).unref();
}
