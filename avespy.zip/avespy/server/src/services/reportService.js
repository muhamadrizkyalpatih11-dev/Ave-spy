import { query, withTransaction } from '../db/pool.js';
import { AppError } from '../utils/errors.js';
import { randomToken, sha256 } from '../utils/crypto.js';
import { audit } from './auditService.js';

const PII_RULES = [
  { re: /[\w.+-]+@[\w-]+\.[\w.-]+/, msg: 'alamat email' },
  { re: /https?:\/\/|www\./i, msg: 'tautan' },
  { re: /(?:\d[\s.-]?){9,}/, msg: 'nomor panjang (telepon, NIK, atau rekening)' },
];

/** Membersihkan deskripsi dan menolak data pribadi. Deskripsi ditampilkan sebagai teks biasa (tidak pernah HTML). */
export function sanitizeDescription(input) {
  if (!input) return null;
  const text = String(input).replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!text) return null;
  for (const rule of PII_RULES) {
    if (rule.re.test(text)) {
      throw new AppError(400, 'PII_DETECTED', `Deskripsi tidak boleh memuat data pribadi: ${rule.msg}.`);
    }
  }
  return text.slice(0, 280);
}

export async function createReport({ e164, country, category, tag, description, reporterHash, ipHash }) {
  const dup = await query(
    `SELECT 1 FROM reports WHERE number_e164 = $1 AND reporter_hash = $2
       AND status <> 'rejected' AND created_at > now() - interval '30 days' LIMIT 1`,
    [e164, reporterHash],
  );
  if (dup.rowCount) {
    throw new AppError(409, 'DUPLICATE_REPORT', 'Anda sudah melaporkan nomor ini. Laporan sedang atau sudah ditinjau moderator.');
  }
  const deleteToken = randomToken(24);
  const { rows } = await query(
    `INSERT INTO reports (number_e164, country, category, tag, description, reporter_hash, delete_token_hash)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [e164, country || null, category, tag || null, description, reporterHash, sha256(deleteToken)],
  );
  const id = rows[0].id;
  await audit({ actorType: 'public', action: 'report.create', target: `report:${id}`, meta: { category }, ipHash });
  return { id: Number(id), deleteToken };
}

export async function listApprovedReports(e164, page = 1, pageSize = 10) {
  const offset = (page - 1) * pageSize;
  const [items, total] = await Promise.all([
    query(
      `SELECT category, tag, description, created_at FROM reports
        WHERE number_e164 = $1 AND status = 'approved'
        ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [e164, pageSize, offset],
    ),
    query(`SELECT count(*)::int AS n FROM reports WHERE number_e164 = $1 AND status = 'approved'`, [e164]),
  ]);
  return {
    total: total.rows[0].n,
    page,
    pageSize,
    reports: items.rows.map((r) => ({
      category: r.category,
      tag: r.tag,
      description: r.description,
      createdAt: r.created_at,
    })),
  };
}

export async function deleteOwnReport(id, token, ipHash) {
  const { rowCount } = await query('DELETE FROM reports WHERE id = $1 AND delete_token_hash = $2', [id, sha256(token)]);
  if (!rowCount) {
    throw new AppError(404, 'NOT_FOUND', 'Laporan tidak ditemukan atau token salah.');
  }
  await audit({ actorType: 'public', action: 'report.self_delete', target: `report:${id}`, ipHash });
}

// ---- Moderasi (admin) ----

export async function listReportsForAdmin({ status, category, page, pageSize }) {
  const where = [];
  const params = [];
  if (status) { params.push(status); where.push(`r.status = $${params.length}`); }
  if (category) { params.push(category); where.push(`r.category = $${params.length}`); }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  params.push(pageSize, (page - 1) * pageSize);
  const { rows } = await query(
    `SELECT r.id, r.number_e164, r.country, r.category, r.tag, r.description, r.status,
            r.created_at, r.moderated_at, r.moderation_note,
            (SELECT count(*)::int FROM reports x WHERE x.number_e164 = r.number_e164 AND x.status = 'approved') AS approved_for_number
       FROM reports r ${clause}
      ORDER BY r.created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params,
  );
  const total = await query(`SELECT count(*)::int AS n FROM reports r ${clause}`, params.slice(0, -2));
  return { total: total.rows[0].n, page, pageSize, items: rows };
}

export async function moderateReport(id, action, note, admin, ipHash) {
  const status = action === 'approve' ? 'approved' : 'rejected';
  const { rowCount } = await query(
    `UPDATE reports SET status = $2, moderated_by = $3, moderated_at = now(), moderation_note = $4 WHERE id = $1`,
    [id, status, admin.id, note || null],
  );
  if (!rowCount) throw new AppError(404, 'NOT_FOUND', 'Laporan tidak ditemukan.');
  await audit({ actorType: 'admin', actorId: admin.id, action: `report.${action}`, target: `report:${id}`, meta: { note: note || null }, ipHash });
}

export async function deleteReportAsAdmin(id, admin, ipHash) {
  const { rowCount } = await query('DELETE FROM reports WHERE id = $1', [id]);
  if (!rowCount) throw new AppError(404, 'NOT_FOUND', 'Laporan tidak ditemukan.');
  await audit({ actorType: 'admin', actorId: admin.id, action: 'report.delete', target: `report:${id}`, ipHash });
}

export { withTransaction };
