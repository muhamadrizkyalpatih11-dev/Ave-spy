import { query } from '../db/pool.js';

export async function getDashboardStats() {
  const [today, week, series, countries, reports, removals, abuse24h] = await Promise.all([
    query(`SELECT COALESCE(sum(count),0)::int AS n FROM lookup_stats WHERE day = CURRENT_DATE`),
    query(`SELECT COALESCE(sum(count),0)::int AS n FROM lookup_stats WHERE day > CURRENT_DATE - 7`),
    query(`SELECT day::text, sum(count)::int AS n FROM lookup_stats WHERE day > CURRENT_DATE - 14 GROUP BY day ORDER BY day`),
    query(`SELECT country, sum(count)::int AS n FROM lookup_stats WHERE day > CURRENT_DATE - 7 GROUP BY country ORDER BY n DESC LIMIT 5`),
    query(`SELECT status, count(*)::int AS n FROM reports GROUP BY status`),
    query(`SELECT count(*)::int AS n FROM removal_requests WHERE status = 'pending'`),
    query(`SELECT type, count(*)::int AS n FROM abuse_events WHERE created_at > now() - interval '24 hours' GROUP BY type ORDER BY n DESC`),
  ]);
  return {
    lookupsToday: today.rows[0].n,
    lookups7d: week.rows[0].n,
    lookupSeries: series.rows,
    topCountries: countries.rows,
    reportsByStatus: Object.fromEntries(reports.rows.map((r) => [r.status, r.n])),
    pendingRemovals: removals.rows[0].n,
    abuseLast24h: abuse24h.rows,
  };
}

export async function listAbuseEvents({ page, pageSize }) {
  const { rows } = await query(
    `SELECT id, type, ip_hash, detail, created_at FROM abuse_events ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
    [pageSize, (page - 1) * pageSize],
  );
  const total = await query('SELECT count(*)::int AS n FROM abuse_events');
  return {
    total: total.rows[0].n,
    page,
    pageSize,
    // hash dipotong: cukup untuk korelasi, tidak dapat dibalik ke IP
    items: rows.map((r) => ({ ...r, ip_hash: r.ip_hash ? r.ip_hash.slice(0, 12) : null })),
  };
}

export async function listAuditLogs({ page, pageSize }) {
  const { rows } = await query(
    `SELECT id, actor_type, actor_id, action, target, meta, created_at FROM audit_logs ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
    [pageSize, (page - 1) * pageSize],
  );
  const total = await query('SELECT count(*)::int AS n FROM audit_logs');
  return { total: total.rows[0].n, page, pageSize, items: rows };
}
