import { query } from '../db/pool.js';

const recentAbuse = new Map();

export async function audit({ actorType, actorId = null, action, target = null, meta = null, ipHash = null }) {
  try {
    await query(
      `INSERT INTO audit_logs (actor_type, actor_id, action, target, meta, ip_hash) VALUES ($1,$2,$3,$4,$5,$6)`,
      [actorType, actorId == null ? null : String(actorId), action, target, meta ? JSON.stringify(meta) : null, ipHash],
    );
  } catch (err) {
    console.error('[audit] gagal menulis log:', err.message);
  }
}

/** Mencatat kejadian abuse; dibatasi 1 catatan/menit per (jenis, IP) agar serangan tidak membanjiri database. */
export function logAbuse(type, ipHash, detail = null) {
  const key = `${type}:${ipHash}`;
  const now = Date.now();
  if (now - (recentAbuse.get(key) || 0) < 60_000) return;
  recentAbuse.set(key, now);
  if (recentAbuse.size > 5000) {
    for (const [k, t] of recentAbuse) if (now - t > 60_000) recentAbuse.delete(k);
  }
  query(`INSERT INTO abuse_events (type, ip_hash, detail) VALUES ($1,$2,$3)`, [
    type,
    ipHash,
    detail ? JSON.stringify(detail) : null,
  ]).catch((err) => console.error('[abuse] gagal menulis event:', err.message));
}
