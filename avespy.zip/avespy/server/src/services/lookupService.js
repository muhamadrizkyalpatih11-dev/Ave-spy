import { query } from '../db/pool.js';
import { hmac } from '../utils/crypto.js';
import { describeNumber } from './phoneService.js';
import { lookupCarrier } from './carrierService.js';
import { computeRisk, computeTags } from './riskService.js';

export const SOURCES = [
  { key: 'format', name: 'libphonenumber (metadata Google, open source)', covers: 'Format, validitas, negara, tipe nomor' },
  { key: 'prefix', name: 'Referensi prefix numbering plan (internal)', covers: 'Indikasi operator' },
  { key: 'community', name: 'Laporan komunitas Avespy (dimoderasi)', covers: 'Risiko, kategori, tag' },
];

export async function isSuppressed(e164) {
  const { rowCount } = await query('SELECT 1 FROM suppressed_numbers WHERE number_hash = $1', [hmac(e164)]);
  return rowCount > 0;
}

export async function lookup(parsed) {
  const base = describeNumber(parsed);
  const e164 = base.number.e164;

  if (await isSuppressed(e164)) {
    return { ...base, suppressed: true, carrier: null, risk: null, tags: [], recentReports: [], sources: SOURCES, checkedAt: new Date().toISOString() };
  }

  const [carrier, reports] = await Promise.all([
    lookupCarrier(parsed.country, parsed.nationalNumber).catch((err) => {
      console.error('[lookup] carrier gagal:', err.message);
      return null;
    }),
    query(
      `SELECT category, tag, description, reporter_hash, created_at
         FROM reports WHERE number_e164 = $1 AND status = 'approved'
         ORDER BY created_at DESC LIMIT 500`,
      [e164],
    ),
  ]);

  const rows = reports.rows;
  recordStat(parsed.country);

  return {
    ...base,
    suppressed: false,
    carrier,
    risk: computeRisk(rows),
    tags: computeTags(rows),
    recentReports: rows.slice(0, 5).map((r) => ({
      category: r.category,
      description: r.description,
      createdAt: r.created_at,
    })),
    sources: SOURCES,
    checkedAt: new Date().toISOString(),
  };
}

function recordStat(country) {
  query(
    `INSERT INTO lookup_stats (day, country, count) VALUES (CURRENT_DATE, $1, 1)
     ON CONFLICT (day, country) DO UPDATE SET count = lookup_stats.count + 1`,
    [country || 'ZZ'],
  ).catch((err) => console.error('[stats] gagal mencatat:', err.message));
}
