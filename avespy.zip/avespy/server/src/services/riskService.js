// Murni (tanpa I/O) agar mudah diuji. Hanya menerima laporan berstatus "approved".

export const CATEGORY_WEIGHT = {
  scam: 1,
  phishing: 1,
  spam: 0.6,
  pinjol: 0.6,
  robocall: 0.5,
  telemarketing: 0.35,
  other: 0.2,
};

const DAY_MS = 86_400_000;
const HALF_LIFE_DAYS = 90;

export function computeRisk(rows, now = Date.now()) {
  if (!rows.length) {
    return {
      status: 'unknown',
      score: null,
      reportCount: 0,
      distinctReporters: 0,
      categories: {},
      lastReportAt: null,
      confidence: 'none',
    };
  }

  let weighted = 0;
  let last = 0;
  const categories = {};
  const reporters = new Set();

  for (const row of rows) {
    const createdAt = new Date(row.created_at).getTime();
    const ageDays = Math.max(0, (now - createdAt) / DAY_MS);
    weighted += (CATEGORY_WEIGHT[row.category] ?? 0.2) * Math.pow(0.5, ageDays / HALF_LIFE_DAYS);
    categories[row.category] = (categories[row.category] || 0) + 1;
    reporters.add(row.reporter_hash);
    if (createdAt > last) last = createdAt;
  }

  const score = Math.min(100, Math.round(100 * (1 - Math.exp(-weighted / 2.5))));
  const status = score < 25 ? 'low' : score < 60 ? 'caution' : 'spam';
  const distinctReporters = reporters.size;
  const confidence = distinctReporters >= 5 ? 'high' : distinctReporters >= 2 ? 'medium' : 'low';

  return {
    status,
    score,
    reportCount: rows.length,
    distinctReporters,
    categories,
    lastReportAt: new Date(last).toISOString(),
    confidence,
  };
}

/** Tag komunitas hanya tampil bila dipakai oleh minimal `minReporters` pelapor berbeda. */
export function computeTags(rows, minReporters = 3) {
  const byTag = new Map();
  for (const row of rows) {
    if (!row.tag) continue;
    if (!byTag.has(row.tag)) byTag.set(row.tag, new Set());
    byTag.get(row.tag).add(row.reporter_hash);
  }
  return [...byTag.entries()]
    .filter(([, set]) => set.size >= minReporters)
    .map(([tag, set]) => ({ tag, count: set.size }))
    .sort((a, b) => b.count - a.count);
}
