import crypto from 'node:crypto';
import { config } from '../config.js';
import { randomToken, safeEqual } from '../utils/crypto.js';

const TTL_MS = 5 * 60_000;
const usedNonces = new Map();

const sign = (payload) => crypto.createHmac('sha256', config.jwtSecret).update(payload).digest('base64url');

function pruneNonces(now) {
  for (const [nonce, exp] of usedNonces) if (exp < now) usedNonces.delete(nonce);
}

/** CAPTCHA bawaan: soal penjumlahan bertanda tangan HMAC (tanpa layanan luar, sekali pakai). */
export function createBuiltinChallenge() {
  const a = 2 + crypto.randomInt(8);
  const b = 2 + crypto.randomInt(8);
  const exp = Date.now() + TTL_MS;
  const nonce = randomToken(8);
  const sig = sign(`${a + b}:${exp}:${nonce}`);
  return { token: `${exp}.${nonce}.${sig}`, question: `Berapa ${a} + ${b}?` };
}

function verifyBuiltin({ token, answer }) {
  if (typeof token !== 'string' || answer == null) return false;
  const [expStr, nonce, sig] = token.split('.');
  const exp = Number(expStr);
  const now = Date.now();
  if (!exp || !nonce || !sig || exp < now || usedNonces.has(nonce)) return false;
  const expected = sign(`${String(answer).trim()}:${exp}:${nonce}`);
  if (!safeEqual(expected, sig)) return false;
  pruneNonces(now);
  usedNonces.set(nonce, exp);
  return true;
}

async function verifyTurnstile({ token }, ip) {
  if (typeof token !== 'string' || !token) return false;
  try {
    const body = new URLSearchParams({ secret: config.captcha.secretKey, response: token });
    if (ip) body.set('remoteip', ip);
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      body,
      signal: AbortSignal.timeout(5000),
    });
    const data = await res.json();
    return data.success === true;
  } catch (err) {
    console.error('[captcha] Turnstile tidak dapat dihubungi:', err.message);
    return false; // gagal tertutup
  }
}

export async function verifyCaptcha(captcha, ip) {
  if (!captcha || typeof captcha !== 'object') return false;
  return config.captcha.provider === 'turnstile' ? verifyTurnstile(captcha, ip) : verifyBuiltin(captcha);
}
