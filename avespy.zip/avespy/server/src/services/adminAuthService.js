import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { query } from '../db/pool.js';
import { AppError } from '../utils/errors.js';
import { audit, logAbuse } from './auditService.js';

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const DUMMY_HASH = bcrypt.hashSync('avespy-dummy-password', 12); // menyamakan waktu respons untuk email yang tidak ada
export const ADMIN_TOKEN_TTL_SECONDS = 8 * 60 * 60;

const GENERIC_FAIL = new AppError(401, 'INVALID_CREDENTIALS', 'Email atau password salah.');

export async function login(email, password, ipHash) {
  const { rows } = await query('SELECT * FROM admins WHERE email = $1', [email.toLowerCase()]);
  const admin = rows[0];

  if (admin?.locked_until && new Date(admin.locked_until) > new Date()) {
    logAbuse('admin_login_locked', ipHash, { adminId: Number(admin.id) });
    throw new AppError(423, 'ACCOUNT_LOCKED', 'Akun dikunci sementara karena terlalu banyak percobaan. Coba lagi nanti.');
  }

  const ok = await bcrypt.compare(password, admin ? admin.password_hash : DUMMY_HASH);
  if (!admin || !ok) {
    if (admin) {
      const attempts = admin.failed_attempts + 1;
      await query(
        `UPDATE admins SET failed_attempts = $2::int,
           locked_until = CASE WHEN $2::int >= $3::int THEN now() + ($4::text || ' minutes')::interval ELSE locked_until END
         WHERE id = $1`,
        [admin.id, attempts, MAX_ATTEMPTS, String(LOCK_MINUTES)],
      );
    }
    logAbuse('admin_login_failed', ipHash, null);
    await audit({ actorType: 'admin', actorId: admin?.id, action: 'admin.login_failed', ipHash });
    throw GENERIC_FAIL;
  }

  await query('UPDATE admins SET failed_attempts = 0, locked_until = NULL, last_login_at = now() WHERE id = $1', [admin.id]);
  await audit({ actorType: 'admin', actorId: admin.id, action: 'admin.login', ipHash });

  const token = jwt.sign({ role: admin.role }, config.jwtSecret, {
    subject: String(admin.id),
    audience: 'avespy-admin',
    issuer: 'avespy',
    expiresIn: ADMIN_TOKEN_TTL_SECONDS,
  });
  return { token, admin: { id: Number(admin.id), email: admin.email, role: admin.role } };
}

export function verifyAdminToken(token) {
  return jwt.verify(token, config.jwtSecret, { audience: 'avespy-admin', issuer: 'avespy' });
}

export async function findAdmin(id) {
  const { rows } = await query('SELECT id, email, role FROM admins WHERE id = $1', [id]);
  return rows[0] ? { id: Number(rows[0].id), email: rows[0].email, role: rows[0].role } : null;
}
