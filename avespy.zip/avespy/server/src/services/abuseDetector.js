import { AppError } from '../utils/errors.js';
import { logAbuse } from './auditService.js';
import { verifyCaptcha } from './captchaService.js';

/**
 * Deteksi abuse berbasis memori proses. Untuk deployment multi-instance,
 * pindahkan state ini ke Redis (antarmuka fungsinya sudah terpisah).
 */
const WINDOW_MS = 60 * 60_000;
const ENUM_WINDOW_MS = 10 * 60_000;
const CAPTCHA_AFTER_DISTINCT = 3;     // nomor berbeda per jam sebelum CAPTCHA diminta
const MAX_DISTINCT_PER_HOUR = 25;     // batas keras pencarian massal
const ENUM_THRESHOLD = 6;             // nomor berurutan (beda hanya 3 digit terakhir)
const BLOCK_MS = 60 * 60_000;
const CAPTCHA_GRACE_MS = 10 * 60_000;

const state = new Map(); // ipHash -> { seen: Map<e164, ts>, blockedUntil, captchaOkUntil }

function get(ipHash) {
  let s = state.get(ipHash);
  if (!s) {
    s = { seen: new Map(), blockedUntil: 0, captchaOkUntil: 0 };
    state.set(ipHash, s);
  }
  return s;
}

function prune(s, now) {
  for (const [num, t] of s.seen) if (now - t > WINDOW_MS) s.seen.delete(num);
}

setInterval(() => {
  const now = Date.now();
  for (const [ip, s] of state) {
    prune(s, now);
    if (!s.seen.size && s.blockedUntil < now && s.captchaOkUntil < now) state.delete(ip);
  }
}, 5 * 60_000).unref();

export function isBlocked(ipHash) {
  return get(ipHash).blockedUntil > Date.now();
}

export function assertNotBlocked(ipHash) {
  if (isBlocked(ipHash)) {
    throw new AppError(429, 'ABUSE_BLOCKED', 'Aktivitas tidak biasa terdeteksi. Coba lagi beberapa saat lagi.');
  }
}

function block(ipHash, s, type, detail) {
  s.blockedUntil = Date.now() + BLOCK_MS;
  logAbuse(type, ipHash, detail);
  throw new AppError(429, 'ABUSE_BLOCKED', 'Aktivitas tidak biasa terdeteksi. Coba lagi beberapa saat lagi.');
}

/**
 * Kebijakan pencarian satu nomor per permintaan:
 *  - menolak IP yang sedang diblokir
 *  - meminta CAPTCHA setelah beberapa nomor berbeda dalam satu jam
 *  - memblokir pola pencarian massal atau enumerasi nomor berurutan
 */
export async function enforceLookupPolicy({ ipHash, ip }, e164, captcha) {
  assertNotBlocked(ipHash);
  const now = Date.now();
  const s = get(ipHash);
  prune(s, now);

  const isNew = !s.seen.has(e164);
  const needsCaptcha = isNew && s.seen.size >= CAPTCHA_AFTER_DISTINCT && s.captchaOkUntil < now;
  if (needsCaptcha) {
    if (!captcha) {
      throw new AppError(428, 'CAPTCHA_REQUIRED', 'Selesaikan verifikasi keamanan untuk melanjutkan.');
    }
    if (!(await verifyCaptcha(captcha, ip))) {
      logAbuse('captcha_failed', ipHash, { context: 'lookup' });
      throw new AppError(428, 'CAPTCHA_REQUIRED', 'Jawaban verifikasi salah. Coba lagi.');
    }
    s.captchaOkUntil = Date.now() + CAPTCHA_GRACE_MS;
  }

  s.seen.set(e164, now);

  if (s.seen.size > MAX_DISTINCT_PER_HOUR) {
    block(ipHash, s, 'bulk_lookup', { distinct: s.seen.size });
  }
  const prefix = e164.slice(0, -3);
  let sameBlock = 0;
  for (const [num, t] of s.seen) {
    if (now - t <= ENUM_WINDOW_MS && num.slice(0, -3) === prefix) sameBlock += 1;
  }
  if (sameBlock >= ENUM_THRESHOLD) {
    block(ipHash, s, 'number_enumeration', { blockSize: sameBlock });
  }
}

export const _internals = { state };
