import { parsePhoneNumberFromString } from 'libphonenumber-js/max';
import { AppError } from '../utils/errors.js';

/** Negara yang tersedia pada pilihan kode negara. */
export const REGIONS = {
  ID: '62', MY: '60', SG: '65', PH: '63', TH: '66', VN: '84', IN: '91', JP: '81', KR: '82', CN: '86',
  AU: '61', US: '1', GB: '44', NL: '31', DE: '49', SA: '966', AE: '971',
};

const displayNames = new Intl.DisplayNames(['id'], { type: 'region' });
export const countryName = (code) => {
  try {
    return code ? displayNames.of(code) : null;
  } catch {
    return null;
  }
};

export const regionList = () =>
  Object.entries(REGIONS).map(([code, callingCode]) => ({ code, callingCode, name: countryName(code) }));

const TYPE_LABELS = {
  MOBILE: 'Seluler (mobile)',
  FIXED_LINE: 'Telepon rumah (landline)',
  FIXED_LINE_OR_MOBILE: 'Seluler atau telepon rumah',
  VOIP: 'VoIP',
  TOLL_FREE: 'Bebas pulsa',
  PREMIUM_RATE: 'Tarif premium',
  SHARED_COST: 'Biaya dibagi',
  PERSONAL_NUMBER: 'Nomor pribadi',
  PAGER: 'Pager',
  UAN: 'Nomor akses universal',
  VOICEMAIL: 'Kotak suara',
};

/** Normalisasi ke E.164. Melempar 422 bila nomor tidak valid. */
export function parseNumber(input, region = 'ID') {
  let parsed;
  try {
    parsed = parsePhoneNumberFromString(String(input), region);
  } catch {
    parsed = undefined;
  }
  if (!parsed || !parsed.isValid()) {
    throw new AppError(422, 'INVALID_NUMBER', 'Nomor telepon tidak valid.');
  }
  return parsed;
}

export function maskNumber(parsed) {
  const nsn = String(parsed.nationalNumber);
  const hidden = Math.max(nsn.length - 5, 2);
  return `+${parsed.countryCallingCode} ${nsn.slice(0, 3)} ${'X'.repeat(hidden)} ${nsn.slice(-2)}`;
}

export function describeNumber(parsed) {
  const typeKey = parsed.getType();
  return {
    number: {
      e164: parsed.number,
      international: parsed.formatInternational(),
      national: parsed.formatNational(),
      masked: maskNumber(parsed),
    },
    valid: true,
    country: {
      code: parsed.country || null,
      name: countryName(parsed.country),
      callingCode: parsed.countryCallingCode,
    },
    type: typeKey ? { key: typeKey, label: TYPE_LABELS[typeKey] || typeKey } : null,
  };
}
