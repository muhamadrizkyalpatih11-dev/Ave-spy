import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { config } from './config.js';
import { pool } from './db/pool.js';
import apiRoutes from './routes/index.js';
import { errorHandler } from './middleware/errorHandler.js';
import { startRetention } from './services/retentionService.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendDir = path.resolve(here, '../../frontend');

const app = express();
app.set('trust proxy', config.trustProxy);
app.disable('x-powered-by');

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", 'https://challenges.cloudflare.com'],
        styleSrc: ["'self'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        frameSrc: ['https://challenges.cloudflare.com'],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: config.isProd ? [] : null,
      },
    },
    referrerPolicy: { policy: 'no-referrer' },
  }),
);

app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());

app.use('/api', apiRoutes);

app.use(
  express.static(frontendDir, {
    extensions: ['html'],
    maxAge: config.isProd ? '1h' : 0,
  }),
);

app.use(errorHandler);

const server = app.listen(config.port, () => {
  console.log(`[avespy] berjalan di http://localhost:${config.port} (${config.env})`);
  pool.query('SELECT 1').then(
    () => startRetention(),
    (err) => console.error('[avespy] database belum dapat dihubungi:', err.message, '\n         Jalankan: docker compose up -d && npm run db:migrate'),
  );
});

function shutdown() {
  server.close(() => pool.end().finally(() => process.exit(0)));
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
