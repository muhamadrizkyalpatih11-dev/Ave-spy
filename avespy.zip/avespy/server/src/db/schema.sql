-- Skema Avespy. Aman dijalankan berulang kali (idempotent).

CREATE TABLE IF NOT EXISTS reports (
  id              BIGSERIAL PRIMARY KEY,
  number_e164     TEXT NOT NULL,
  country         TEXT,
  category        TEXT NOT NULL CHECK (category IN ('scam','spam','telemarketing','pinjol','phishing','robocall','other')),
  tag             TEXT,
  description     TEXT,
  reporter_hash   TEXT NOT NULL,            -- HMAC(IP), bukan IP asli
  delete_token_hash TEXT NOT NULL,          -- pelapor dapat menghapus laporannya sendiri
  status          TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  moderated_by    BIGINT,
  moderated_at    TIMESTAMPTZ,
  moderation_note TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS reports_number_status_idx ON reports (number_e164, status);
CREATE INDEX IF NOT EXISTS reports_status_created_idx ON reports (status, created_at DESC);
CREATE INDEX IF NOT EXISTS reports_reporter_idx ON reports (reporter_hash, number_e164);

CREATE TABLE IF NOT EXISTS removal_requests (
  id            BIGSERIAL PRIMARY KEY,
  number_e164   TEXT,                       -- dikosongkan setelah permintaan diproses
  number_hash   TEXT NOT NULL,
  contact_email TEXT,                       -- dihapus 30 hari setelah diproses
  reason        TEXT,
  status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  handled_by    BIGINT,
  handled_at    TIMESTAMPTZ,
  note          TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS removal_status_idx ON removal_requests (status, created_at DESC);

-- Nomor yang pemiliknya meminta penghapusan. Hanya hash yang disimpan.
CREATE TABLE IF NOT EXISTS suppressed_numbers (
  number_hash TEXT PRIMARY KEY,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admins (
  id              BIGSERIAL PRIMARY KEY,
  email           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'moderator' CHECK (role IN ('moderator','admin')),
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until    TIMESTAMPTZ,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  actor_type  TEXT NOT NULL,                -- 'admin' | 'public' | 'system'
  actor_id    TEXT,
  action      TEXT NOT NULL,
  target      TEXT,
  meta        JSONB,
  ip_hash     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_logs (created_at DESC);

CREATE TABLE IF NOT EXISTS abuse_events (
  id         BIGSERIAL PRIMARY KEY,
  type       TEXT NOT NULL,
  ip_hash    TEXT,
  detail     JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS abuse_created_idx ON abuse_events (created_at DESC);

-- Statistik pencarian agregat. TIDAK menyimpan nomor yang dicari.
CREATE TABLE IF NOT EXISTS lookup_stats (
  day     DATE NOT NULL,
  country TEXT NOT NULL,
  count   INT NOT NULL DEFAULT 0,
  PRIMARY KEY (day, country)
);

-- Referensi prefix numbering plan (bukan bukti operator saat ini karena ada portabilitas nomor).
CREATE TABLE IF NOT EXISTS carrier_prefixes (
  country TEXT NOT NULL,
  prefix  TEXT NOT NULL,
  carrier TEXT NOT NULL,
  PRIMARY KEY (country, prefix)
);
