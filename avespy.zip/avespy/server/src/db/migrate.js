import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from './pool.js';

const here = path.dirname(fileURLToPath(import.meta.url));

// Alokasi prefix numbering plan Indonesia (nomor nasional tanpa 0 di depan).
// Ini referensi awal; perbarui dari data resmi regulator (Komdigi/BRTI) secara berkala.
const ID_PREFIXES = {
  Telkomsel: ['811', '812', '813', '821', '822', '823', '851', '852', '853'],
  'Indosat Ooredoo Hutchison': ['814', '815', '816', '855', '856', '857', '858', '895', '896', '897', '898', '899'],
  'XL Axiata': ['817', '818', '819', '859', '877', '878'],
  'Axis (XL Axiata)': ['831', '832', '833', '838'],
  Smartfren: ['881', '882', '883', '884', '885', '886', '887', '888', '889'],
};

async function main() {
  const sql = await fs.readFile(path.join(here, 'schema.sql'), 'utf8');
  await pool.query(sql);
  for (const [carrier, prefixes] of Object.entries(ID_PREFIXES)) {
    for (const prefix of prefixes) {
      await pool.query(
        `INSERT INTO carrier_prefixes (country, prefix, carrier) VALUES ('ID', $1, $2)
         ON CONFLICT (country, prefix) DO UPDATE SET carrier = EXCLUDED.carrier`,
        [prefix, carrier],
      );
    }
  }
  console.log('[migrate] skema dan referensi prefix siap.');
}

main()
  .catch((err) => {
    console.error('[migrate] gagal:', err.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
