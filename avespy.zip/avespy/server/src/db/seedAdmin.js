import bcrypt from 'bcryptjs';
import { pool } from './pool.js';

async function main() {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!email || password.length < 12) {
    throw new Error('Set ADMIN_EMAIL dan ADMIN_PASSWORD (minimal 12 karakter) di .env terlebih dahulu.');
  }
  const hash = await bcrypt.hash(password, 12);
  await pool.query(
    `INSERT INTO admins (email, password_hash, role) VALUES ($1, $2, 'admin')
     ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = 'admin',
       failed_attempts = 0, locked_until = NULL`,
    [email, hash],
  );
  console.log(`[seed-admin] admin siap: ${email}`);
}

main()
  .catch((err) => {
    console.error('[seed-admin] gagal:', err.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
