import test from 'node:test';
import assert from 'node:assert/strict';
import { computeRisk, computeTags } from '../src/services/riskService.js';

const NOW = Date.parse('2026-09-30T00:00:00Z');
const row = (category, reporter, daysAgo = 0, tag) => ({
  category,
  reporter_hash: reporter,
  tag,
  created_at: new Date(NOW - daysAgo * 86_400_000).toISOString(),
});

test('tanpa laporan: status unknown, tidak mengarang skor', () => {
  const r = computeRisk([], NOW);
  assert.equal(r.status, 'unknown');
  assert.equal(r.score, null);
  assert.equal(r.confidence, 'none');
});

test('satu laporan telemarketing: risiko rendah', () => {
  assert.equal(computeRisk([row('telemarketing', 'a')], NOW).status, 'low');
});

test('satu laporan penipuan baru: perlu waspada', () => {
  assert.equal(computeRisk([row('scam', 'a')], NOW).status, 'caution');
});

test('tiga laporan penipuan dari pelapor berbeda: terindikasi spam, kepercayaan sedang', () => {
  const r = computeRisk([row('scam', 'a'), row('scam', 'b'), row('scam', 'c')], NOW);
  assert.equal(r.status, 'spam');
  assert.equal(r.confidence, 'medium');
  assert.equal(r.categories.scam, 3);
});

test('laporan lama meluruh', () => {
  const fresh = computeRisk([row('scam', 'a', 0)], NOW).score;
  const old = computeRisk([row('scam', 'a', 365)], NOW).score;
  assert.ok(old < fresh);
});

test('tag hanya tampil bila dipakai >= 3 pelapor berbeda', () => {
  const two = [row('spam', 'a', 0, 'sales'), row('spam', 'b', 0, 'sales')];
  assert.deepEqual(computeTags(two), []);
  const three = [...two, row('spam', 'c', 0, 'sales')];
  assert.deepEqual(computeTags(three), [{ tag: 'sales', count: 3 }]);
});
